package mtbs.mtbs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MtbsApplicationTests {

	@Test
	void contextLoads() {
	}

}
