package mtbs.mtbs.Repository;

import mtbs.mtbs.Model.Bookings;
import mtbs.mtbs.dto.BookingWithShowtimeDto;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface BookingsRepository extends JpaRepository<Bookings, Integer> {

    // Find bookings by user ID
    List<Bookings> findByUser_UserId(Integer userId);

    // Find bookings within a date/time range based on showtime start
    List<Bookings> findByBookingDateBetween(Timestamp from, Timestamp to);
//    List<BookingWithShowtimeDto> findByBookingDateBetween1(Timestamp from, Timestamp to);
    List<Bookings> findByShowtime_StartTimeBetween(LocalDateTime from, LocalDateTime to);


}
