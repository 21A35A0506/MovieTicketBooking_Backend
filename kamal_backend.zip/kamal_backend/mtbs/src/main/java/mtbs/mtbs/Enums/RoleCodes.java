package mtbs.mtbs.Enums;

public enum RoleCodes {
    ADMIN,CUSTOMER
}