package mtbs.mtbs.Services;

import mtbs.mtbs.Enums.ActionType;
import mtbs.mtbs.Enums.ActiveCodes;
import mtbs.mtbs.Model.*;
import mtbs.mtbs.Repository.*;
import mtbs.mtbs.dto.TheatreDto;
import mtbs.mtbs.dto.TheatreShowtimeDto;
import mtbs.mtbs.dto.TheatreShowtimeDto.ShowtimeInfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TheatresService {

    @Autowired
    private TheatresRepository theatresRepository;
    @Autowired
    private UsersRepository usersRepository;
    @Autowired
    private AuditLogsRepository auditLogsRepository;
    @Autowired
    private ScreensRepository screensRepository;
    @Autowired
    private ShowtimesRepository showtimesRepository;

    @Transactional
    public String addTheatre(TheatreDto dto, Integer adminId) throws Exception {
        Optional<Users> adminOpt = usersRepository.findById(adminId);
        if (adminOpt.isEmpty() || adminOpt.get().getRole() != Users.Role.ADMIN) {
            throw new Exception("Only admins can add theatres.");
        }
        Theatres theatre = new Theatres();
        theatre.setName(dto.getName());
        theatre.setLocation(dto.getLocation());
        theatre.setCity(dto.getCity());
        theatre.setCapacity(dto.getCapacity());
        theatre.setIsActive(ActiveCodes.ACTIVE); // status
        theatre.setCreatedBy(adminOpt.get());
        theatre.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        theatre.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
        theatresRepository.save(theatre);

        logAudit("theatres", theatre.getTheaterId(), "INSERT", adminId);

        return "Theatre added successfully!";
    }

    // Only ACTIVE theatres for user/admin list
    public List<TheatreDto> getAllTheatres() {
        return theatresRepository.findByIsActive(ActiveCodes.ACTIVE).stream()
            .map(this::convertToDto)
            .collect(Collectors.toList());
    }

    // Search with status filter
    public List<TheatreDto> searchTheatres(String city, String location) {
        List<Theatres> results;
        if (city != null && location != null) {
            results = theatresRepository.findByCityIgnoreCaseAndLocationIgnoreCaseAndIsActive(city, location, ActiveCodes.ACTIVE);
        } else if (city != null) {
            results = theatresRepository.findByCityIgnoreCaseAndIsActive(city, ActiveCodes.ACTIVE);
        } else if (location != null) {
            results = theatresRepository.findByLocationIgnoreCaseAndIsActive(location, ActiveCodes.ACTIVE);
        } else {
            results = theatresRepository.findByIsActive(ActiveCodes.ACTIVE);
        }
        return results.stream().map(this::convertToDto).collect(Collectors.toList());
    }

    // Include isActive check
    public TheatreDto getTheatreById(Integer theatreId) throws Exception {
        Optional<Theatres> theatreOpt = theatresRepository.findById(theatreId);
        if (theatreOpt.isEmpty() || theatreOpt.get().getIsActive() != ActiveCodes.ACTIVE)
            throw new Exception("Theatre not found");
        return convertToDto(theatreOpt.get());
    }
    
    

public TheatreShowtimeDto getTheatreShowtimes(Integer theatreId) throws Exception {
    // Fetch the theatre (active check included)
    Optional<Theatres> theatreOpt = theatresRepository.findById(theatreId);
    if (theatreOpt.isEmpty() || theatreOpt.get().getIsActive() != ActiveCodes.ACTIVE) {
        throw new Exception("Theatre not found or inactive.");
    }
    Theatres theatre = theatreOpt.get();

    // Fetch screens for theatre (only active screens)
    List<Screens> screens = screensRepository.findByTheatre_TheaterId(theatreId)
        .stream()
        .filter(s -> s.getIsActive() == ActiveCodes.ACTIVE)
        .collect(Collectors.toList());

    List<ShowtimeInfo> allShowtimes = screens.stream()
        .flatMap(screen -> {
            // Fetch active showtimes per screen
            List<Showtimes> showtimes = showtimesRepository.findByScreen_ScreenId(screen.getScreenId())
                .stream()
                .filter(st -> st.getIsActive() == ActiveCodes.ACTIVE)
                .collect(Collectors.toList());

            return showtimes.stream().map(st -> new TheatreShowtimeDto.ShowtimeInfo(
                    st.getShowtimeId(),
                    st.getStartTime(),
                    st.getEndTime(),
                    st.getPrice(),
                    st.getAvailableSeats(),
                    st.getMovie().getMovieId(),
                    st.getMovie().getTitle(),
                    screen.getScreenId(),
                    screen.getScreenName()
            ));
        })
        .collect(Collectors.toList());

    // Construct DTO
    return new TheatreShowtimeDto(
            theatre.getTheaterId(),
            theatre.getName(),
            theatre.getCity(),
            allShowtimes
    );
}


    @Transactional
    public String updateTheatre(Integer theatreId, TheatreDto updatedDto, Integer adminId) throws Exception {
        Optional<Theatres> theatreOpt = theatresRepository.findById(theatreId);
        Optional<Users> adminOpt = usersRepository.findById(adminId);

        if (theatreOpt.isEmpty())
            throw new Exception("Theatre not found");
        if (adminOpt.isEmpty() || adminOpt.get().getRole() != Users.Role.ADMIN)
            throw new Exception("Only admins can update theatres.");

        Theatres theatre = theatreOpt.get();
        theatre.setName(updatedDto.getName());
        theatre.setLocation(updatedDto.getLocation());
        theatre.setCity(updatedDto.getCity());
        theatre.setCapacity(updatedDto.getCapacity());
//        theatre.setIsActive(updatedDto.getIsActive());
        theatre.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
        theatresRepository.save(theatre);

        logAudit("theatres", theatreId, "UPDATE", adminId);

        return "Theatre updated successfully!";
    }

    // SOFT DELETE + CASCADE
    @Transactional
    public String deleteTheatre(Integer theatreId, Integer adminId) throws Exception {
        Optional<Theatres> theatreOpt = theatresRepository.findById(theatreId);
        Optional<Users> adminOpt = usersRepository.findById(adminId);

        if (theatreOpt.isEmpty())
            throw new Exception("Theatre not found");
        if (adminOpt.isEmpty() || adminOpt.get().getRole() != Users.Role.ADMIN)
            throw new Exception("Only admins can delete theatres.");

        Theatres theatre = theatreOpt.get();
        theatre.setIsActive(ActiveCodes.INACTIVE);
        theatresRepository.save(theatre);

        // Cascade: set all screens and showtimes as INACTIVE
        List<Screens> screens = screensRepository.findByTheatre_TheaterId(theatreId);
        for (Screens screen : screens) {
            screen.setIsActive(ActiveCodes.INACTIVE);
            screensRepository.save(screen);

            List<Showtimes> showtimes = showtimesRepository.findByScreen_ScreenId(screen.getScreenId());
            for (Showtimes showtime : showtimes) {
                showtime.setIsActive(ActiveCodes.INACTIVE);
                showtimesRepository.save(showtime);
            }
        }

        logAudit("theatres", theatreId, "DELETE", adminId);

        return "Theatre and all associated screens and showtimes marked as inactive.";
    }

    private TheatreDto convertToDto(Theatres theatre) {
        TheatreDto dto = new TheatreDto();
        dto.setTheatreId(theatre.getTheaterId());
        dto.setName(theatre.getName());
        dto.setLocation(theatre.getLocation());
        dto.setCity(theatre.getCity());
        dto.setCapacity(theatre.getCapacity());
        return dto;
    }

    private void logAudit(String tableName, Integer recordId, String action, Integer changedById) {
        AuditLogs audit = new AuditLogs();
        audit.setTableName(tableName);
        audit.setRecordId(recordId);
        try {
            ActionType actionType = ActionType.valueOf(action.toUpperCase());
            audit.setAction(actionType);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid action type: " + action);
        }
        Users user = new Users();
        user.setUserId(changedById);
        audit.setChangedBy(user);
        audit.setChangedAt(new Timestamp(System.currentTimeMillis()));
        auditLogsRepository.save(audit);
    }
}
