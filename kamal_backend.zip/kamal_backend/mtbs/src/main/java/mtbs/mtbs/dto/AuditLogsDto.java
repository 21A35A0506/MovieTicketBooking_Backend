package mtbs.mtbs.dto;

import mtbs.mtbs.Enums.ActionType;
import java.sql.Timestamp;

public class AuditLogsDto {
    private Integer auditId;
    private String tableName;
    private Integer recordId;
    private ActionType action;
    private Integer changedById;
    private Timestamp changedAt;

    public Integer getAuditId() { return auditId; }
    public void setAuditId(Integer auditId) { this.auditId = auditId; }

    public String getTableName() { return tableName; }
    public void setTableName(String tableName) { this.tableName = tableName; }

    public Integer getRecordId() { return recordId; }
    public void setRecordId(Integer recordId) { this.recordId = recordId; }

    public ActionType getAction() { return action; }
    public void setAction(ActionType action) { this.action = action; }

    public Integer getChangedById() { return changedById; }
    public void setChangedById(Integer changedById) { this.changedById = changedById; }

    public Timestamp getChangedAt() { return changedAt; }
    public void setChangedAt(Timestamp changedAt) { this.changedAt = changedAt; }
}
