package mtbs.mtbs.Model;

import jakarta.persistence.*;
import mtbs.mtbs.Enums.ActionType;

import java.sql.Timestamp;

@Entity
@Table(name = "audit_logs")
public class AuditLogs {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "log_id")
    private Integer logId;

    @Column(name = "table_name", nullable = false, length = 50)
    private String tableName;

    @Column(name = "record_id", nullable = false)
    private Integer recordId;

    @Enumerated(EnumType.STRING)
    @Column(name = "action", nullable = false, length = 10)
    private ActionType action; // 'INSERT','UPDATE','DELETE'

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "changed_by", nullable = false)
    private Users changedBy;

    @Column(name = "changed_at", nullable = false,
            columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp changedAt;

    // Enum for action type
//    public enum ActionType {
//        INSERT, UPDATE, DELETE
//    }

    // Constructors
    public AuditLogs() {}

    public AuditLogs(String tableName, Integer recordId, ActionType action, Users changedBy) {
        this.tableName = tableName;
        this.recordId = recordId;
        this.action = action;
        this.changedBy = changedBy;
    }

    // Getters and Setters
    public Integer getLogId() { return logId; }
    public void setLogId(Integer logId) { this.logId = logId; }

    public String getTableName() { return tableName; }
    public void setTableName(String tableName) { this.tableName = tableName; }

    public Integer getRecordId() { return recordId; }
    public void setRecordId(Integer recordId) { this.recordId = recordId; }

    public ActionType getAction() { return action; }
    public void setAction(ActionType action) { this.action = action; }

    public Users getChangedBy() { return changedBy; }
    public void setChangedBy(Users changedBy) { this.changedBy = changedBy; }

    public Timestamp getChangedAt() { return changedAt; }
    public void setChangedAt(Timestamp changedAt) { this.changedAt = changedAt; }


}
