package mtbs.mtbs.Services;

import mtbs.mtbs.Enums.ActionType;
import mtbs.mtbs.Model.*;
import mtbs.mtbs.Repository.*;
import mtbs.mtbs.dto.BookingDto;
import mtbs.mtbs.dto.BookingWithShowtimeDto;
import mtbs.mtbs.dto.ViewBookingsDto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.Map;

@Service
public class BookingsService {

    @Autowired private BookingsRepository bookingsRepository;
    @Autowired private UsersRepository usersRepository;
    @Autowired private ShowtimesRepository showtimesRepository;
    @Autowired private BookingSeatsRepository bookingSeatsRepository;
    @Autowired private AuditLogsRepository auditLogsRepository;
    @Autowired private ScreensRepository screensRepository;

    // ===========================
    // Booking CRUD
    // ===========================
    @Transactional
    public BookingDto createBooking(Integer userId, Integer showtimeId, List<String> seatNumbers) throws Exception {
        Users user = usersRepository.findById(userId)
                .orElseThrow(() -> new Exception("User not found."));
        Showtimes showtime = showtimesRepository.findById(showtimeId)
                .orElseThrow(() -> new Exception("Showtime not found."));

        if (seatNumbers.size() > showtime.getAvailableSeats()) {
            throw new Exception("Not enough seats available.");
        }

        // Calculate total price
        BigDecimal seatPrice = showtime.getPrice();
        int noOfTickets = seatNumbers.size();
        BigDecimal total = seatPrice.multiply(BigDecimal.valueOf(noOfTickets));

        showtime.setAvailableSeats(showtime.getAvailableSeats() - noOfTickets);
        showtimesRepository.save(showtime);

        Bookings booking = new Bookings();
        booking.setUser(user);
        booking.setShowtime(showtime);
        booking.setBookingDate(Timestamp.valueOf(showtime.getStartTime()));
        booking.setTotalAmount(total);
        booking.setStatus(Bookings.BookingStatus.CONFIRMED);
        booking.setPaymentStatus(Bookings.PaymentStatus.COMPLETED);
        booking.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        booking.setUpdatedAt(new Timestamp(System.currentTimeMillis()));

        bookingsRepository.save(booking);

        // Save booked seats
        for (String seat : seatNumbers) {
            BookingSeats bs = new BookingSeats(booking, seat, seatPrice);
            bs.setCreatedAt(new Timestamp(System.currentTimeMillis()));
            bookingSeatsRepository.save(bs);
        }

        logAudit("bookings", booking.getBookingId(), "INSERT", userId);

        return convertToDto(booking);
    }

    @Transactional
	public List<BookingDto> getBookingsByUser(Integer userId) throws Exception {
	    Optional<Users> userOpt = usersRepository.findById(userId);
	    if (userOpt.isEmpty()) {
	        throw new Exception("User not found.");
	    }

	    List<Bookings> bookingsList = bookingsRepository.findByUser_UserId(userId);

	    // Update status to COMPLETED for past bookings not CANCELLED or COMPLETED
	    LocalDateTime now = LocalDateTime.now();
	    boolean updated = false;
	    for (Bookings booking : bookingsList) {
	        if (booking.getBookingDate().toLocalDateTime().isBefore(now) 
	            && booking.getStatus() != Bookings.BookingStatus.CANCELLED 
	            && booking.getStatus() != Bookings.BookingStatus.COMPLETED) {
	            booking.setStatus(Bookings.BookingStatus.COMPLETED);
	            updated = true;
	        }
	    }
	    if (updated) {
	        bookingsRepository.saveAll(bookingsList);
	    }

	    return bookingsList.stream().map(this::convertToDto).collect(Collectors.toList());
	}

    public List<BookingDto> getAllBookings() {
        return bookingsRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

	public List<Bookings> getAllBookingsRange(String from, String to) {
		if (from != null && to != null) {
			Timestamp fromTimestamp = Timestamp.valueOf(from + " 00:00:00");
			Timestamp toTimestamp = Timestamp.valueOf(to + " 23:59:59");
			return bookingsRepository.findByBookingDateBetween(fromTimestamp, toTimestamp);
		}
		return bookingsRepository.findAll();
	}

	
	public String generateBookingsCsv() {
		List<BookingDto> bookings = getAllBookings();

		StringBuilder csvBuilder = new StringBuilder();

		csvBuilder.append(
				"Booking ID,User ID,Showtime ID,Booking Date,Total Amount,Status,Payment Status,Movie Name,Theater Name\n");

		for (BookingDto b : bookings) {
			csvBuilder.append(String.format("%d,%d,%d,%s,%s,%s,%s,%s,%s\n", b.getBookingId(),
					b.getUserId() != null ? b.getUserId() : 0, b.getShowtimeId() != null ? b.getShowtimeId() : 0,
					b.getBookingDate() != null ? b.getBookingDate().toString() : "",
					b.getTotalAmount() != null ? b.getTotalAmount().toPlainString() : "0",
					b.getStatus() != null ? b.getStatus() : "",
					b.getPaymentStatus() != null ? b.getPaymentStatus() : "",
					b.getMovieName() != null ? b.getMovieName() : "",
					b.getTheaterName() != null ? b.getTheaterName() : ""));
		}

		return csvBuilder.toString();
	}
	
	
	
    // ===========================
    // BookingWithShowtime APIs
    // ===========================
    public List<BookingWithShowtimeDto> getAllBookingswithoutfilter() {
        return bookingsRepository.findAll().stream()
                .map(this::mapToShowtimeDto)
                .collect(Collectors.toList());
    }

//    public List<BookingWithShowtimeDto> getAllBookingsRange(Timestamp from, Timestamp to) {
//    		if (from != null && to != null) {
////    			Timestamp fromTimestamp = Timestamp.valueOf(from + " 00:00:00");
////    			Timestamp toTimestamp = Timestamp.valueOf(to + " 23:59:59");
//    			return bookingsRepository.findByBookingDateBetweenShowtime(from, to);
//    		}
//    		return bookingsRepository.findAll();
//    	}

    // ===========================
    // Mapping Methods
    // ===========================
    private BookingDto convertToDto(Bookings booking) {
        BookingDto dto = new BookingDto();
        dto.setBookingId(booking.getBookingId());
        dto.setUserId(booking.getUser() != null ? booking.getUser().getUserId() : null);
        dto.setShowtimeId(booking.getShowtime() != null ? booking.getShowtime().getShowtimeId() : null);
        dto.setBookingDate(booking.getBookingDate());
        dto.setTotalAmount(booking.getTotalAmount());
        dto.setStatus(booking.getStatus() != null ? booking.getStatus().name() : null);
        dto.setPaymentStatus(booking.getPaymentStatus() != null ? booking.getPaymentStatus().name() : null);

        if (booking.getShowtime() != null) {
            Movies movie = booking.getShowtime().getMovie();
            if (movie != null) dto.setMovieName(movie.getTitle());
            Screens screen = booking.getShowtime().getScreen();
            if (screen != null && screen.getTheatre() != null) {
                dto.setTheaterName(screen.getTheatre().getName());
            }
        }
        return dto;
    }

    private BookingWithShowtimeDto mapToShowtimeDto(Bookings booking) {
        Showtimes showtime = booking.getShowtime();
        List<String> seats = (booking.getBookingSeats() != null)
                ? booking.getBookingSeats().stream()
                        .map(BookingSeats::getSeatNumber)
                        .collect(Collectors.toList())
                : List.of();

        BookingWithShowtimeDto dto = new BookingWithShowtimeDto();
        dto.setBookingId(booking.getBookingId());
        dto.setUserId(booking.getUser() != null ? booking.getUser().getUserId() : null);
        dto.setUserName(booking.getUser() != null ? booking.getUser().getUsername() : null);
        dto.setUserEmail(booking.getUser() != null ? booking.getUser().getEmail() : null);
        dto.setBookingDate(booking.getBookingDate());
        dto.setSeatNumbers(seats);
        dto.setSeatCount(seats.size());
        dto.setPaymentStatus(booking.getPaymentStatus() != null ? booking.getPaymentStatus().toString() : null);
        dto.setTotalAmount(booking.getTotalAmount());

        if (showtime != null) {
            dto.setShowtimeLabel(getShowtimeLabel(showtime.getStartTime()));
            if (showtime.getMovie() != null) dto.setMovieTitle(showtime.getMovie().getTitle());
            if (showtime.getScreen() != null && showtime.getScreen().getTheatre() != null) {
                dto.setTheatreName(showtime.getScreen().getTheatre().getName());
            }
        }
        return dto;
    }

    private String getShowtimeLabel(LocalDateTime startTime) {
        if (startTime == null) return null;
        int hour = startTime.getHour();
        if (hour >= 6 && hour < 12) return "Morning Show";
        if (hour >= 12 && hour < 16) return "Matinee Show";
        if (hour >= 16 && hour < 20) return "Evening Show";
        return "Second Show";
    }

    // ===========================
    // Audit Logging
    // ===========================
    private void logAudit(String tableName, Integer recordId, String action, Integer changedById) {
        AuditLogs audit = new AuditLogs();
        audit.setTableName(tableName);
        audit.setRecordId(recordId);
        try {
            audit.setAction(ActionType.valueOf(action.toUpperCase()));
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Invalid action type: " + action);
        }

        Users user = new Users();
        user.setUserId(changedById);
        audit.setChangedBy(user);
        audit.setChangedAt(new Timestamp(System.currentTimeMillis()));
        auditLogsRepository.save(audit);
    }
    

	@Transactional
	public String cancelBooking(Integer bookingId, Integer userId) throws Exception {
		Optional<Bookings> bookingOpt = bookingsRepository.findById(bookingId);
		if (bookingOpt.isEmpty()) {
			throw new Exception("Booking not found.");
		}
		Bookings booking = bookingOpt.get();
		if (!booking.getUser().getUserId().equals(userId)) {
			throw new Exception("You can only cancel your own bookings.");
		}
		booking.setStatus(Bookings.BookingStatus.CANCELLED);
		booking.setPaymentStatus(Bookings.PaymentStatus.REFUNDED);
		booking.setUpdatedAt(new Timestamp(System.currentTimeMillis()));

		bookingsRepository.save(booking);

		List<BookingSeats> seats = bookingSeatsRepository.findByBooking_BookingId(bookingId);
		Showtimes showtime = booking.getShowtime();
		showtime.setAvailableSeats(showtime.getAvailableSeats() + seats.size());
		showtimesRepository.save(showtime);
//		Screens screens = showtime.getScreen();
		// Parse the seats list JSON into a Map<String, String[]>
		ShowtimesService showtimesService = new ShowtimesService();
		Map<String, String[]> seatMap = showtimesService.parseSeatsString(showtime.getSeatsList());

		// Iterate through all booked seats and change them back to "available"
		for (BookingSeats bookingSeat : seats) {
			String seatNumber = bookingSeat.getSeatNumber(); // Seat number like "C16"

			// Extract the row (e.g., "C") and column index (e.g., 16) from the seatNumber
			String row = seatNumber.substring(0, 1); // The first character is the row (e.g., "C")
			int colIndex = Integer.parseInt(seatNumber.substring(1)) - 1; // The remaining characters are the column
																			// index (adjusted to 0-based index)

			if (seatMap.containsKey(row)) {
				String[] rowSeats = seatMap.get(row);
				if (colIndex >= 0 && colIndex < rowSeats.length) {
					rowSeats[colIndex] = "available"; // Mark seat as "available"
				}
			}
		}

		// Convert the updated seat map back to JSON or appropriate format and update
		// the screen's seats
		String updatedSeatsList = showtimesService.convertSeatsMapToJson(seatMap);
		showtime.setSeatsList(updatedSeatsList);
		showtimesRepository.save(showtime); // Save t

		bookingSeatsRepository.deleteAll(seats);

		logAudit("bookings", bookingId, "DELETE", userId);

		return "Booking cancelled and seats released.";
	}
	
	@Transactional
	public String updatePaymentStatus(Integer bookingId, Bookings.PaymentStatus status, Integer adminId)
			throws Exception {
		Optional<Bookings> bookingOpt = bookingsRepository.findById(bookingId);
		if (bookingOpt.isEmpty()) {
			throw new Exception("Booking not found.");
		}
		Bookings booking = bookingOpt.get();
		booking.setPaymentStatus(status);
		bookingsRepository.save(booking);

		logAudit("bookings", bookingId, "UPDATE", adminId);

		return "Payment status updated.";
	}
	
	public List<BookingDto> getBookingDetails(Integer bookingId) {
		return bookingsRepository.findById(bookingId).stream().map(this::convertToDto).collect(Collectors.toList());
	}
	
	@Transactional
	public String updateStatus(Integer bookingId, Bookings.BookingStatus status, Integer adminId)
			throws Exception {
		Optional<Bookings> bookingOpt = bookingsRepository.findById(bookingId);
		if (bookingOpt.isEmpty()) {
			throw new Exception("Booking not found.");
		}
		Bookings booking = bookingOpt.get();
		booking.setStatus(status);
		bookingsRepository.save(booking);

		logAudit("bookings", bookingId, "UPDATE", adminId);

		return "Payment status updated.";
	}

}