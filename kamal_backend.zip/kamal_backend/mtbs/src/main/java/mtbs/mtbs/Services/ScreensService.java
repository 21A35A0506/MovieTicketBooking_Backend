package mtbs.mtbs.Services;

import mtbs.mtbs.Enums.ActionType;
import mtbs.mtbs.Enums.ActiveCodes;
import mtbs.mtbs.Model.*;
import mtbs.mtbs.Repository.*;
import mtbs.mtbs.dto.ScreensDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;
import com.fasterxml.jackson.core.type.TypeReference;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ScreensService {

	@Autowired
	private ScreensRepository screensRepository;

	@Autowired
	private TheatresRepository theatresRepository;

	@Autowired
	private UsersRepository usersRepository;

	@Autowired
	private AuditLogsRepository auditLogsRepository;

	@Autowired
	private ShowtimesRepository showtimesRepository;

	@Transactional
	public String addScreen(ScreensDto dto, Integer adminId) throws Exception {
		Optional<Theatres> theatreOpt = theatresRepository.findById(dto.getTheatreId());
		Optional<Users> adminOpt = usersRepository.findById(adminId);

		if (theatreOpt.isEmpty() || adminOpt.isEmpty() || adminOpt.get().getRole() != Users.Role.ADMIN) {
			throw new Exception("Invalid theatre or unauthorized admin.");
		}
		Screens screen = new Screens();
		screen.setScreenName(dto.getScreenName());
		screen.setCapacity(100);
		screen.setTheatre(theatreOpt.get());
		screen.setIsActive(ActiveCodes.ACTIVE);
		screen.setCreatedAt(new Timestamp(System.currentTimeMillis()));
		screen.setUpdatedAt(new Timestamp(System.currentTimeMillis()));

		screensRepository.save(screen);

		logAudit("screens", screen.getScreenId(), "INSERT", adminId);

		return "Screen added successfully!";
	}

	// Only show ACTIVE screens
	public List<ScreensDto> getAllScreens() {
		return screensRepository.findByIsActive(ActiveCodes.ACTIVE).stream().map(this::convertToDto)
				.collect(Collectors.toList());
	}

	public List<ScreensDto> getScreensByTheatre(Integer theatreId) {
		return screensRepository.findByTheatre_TheaterIdAndIsActive(theatreId, ActiveCodes.ACTIVE).stream()
				.map(this::convertToDto).collect(Collectors.toList());
	}

	@Transactional
	public String updateScreen(Integer screenId, ScreensDto updatedDto, Integer adminId) throws Exception {
		Optional<Screens> screenOpt = screensRepository.findById(screenId);
		Optional<Users> adminOpt = usersRepository.findById(adminId);

		if (screenOpt.isEmpty())
			throw new Exception("Screen not found");
		if (adminOpt.isEmpty() || adminOpt.get().getRole() != Users.Role.ADMIN)
			throw new Exception("Unauthorized");
		Screens screen = screenOpt.get();
		screen.setScreenName(updatedDto.getScreenName());
		screen.setCapacity(100);
		screen.setIsActive(updatedDto.getIsActive());
		screen.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
		screensRepository.save(screen);

		logAudit("screens", screenId, "UPDATE", adminId);

		return "Screen updated successfully!";
	}

	// SOFT DELETE + cascade to showtimes
	@Transactional
	public String deleteScreen(Integer screenId, Integer adminId) throws Exception {
		Optional<Screens> screenOpt = screensRepository.findById(screenId);
		Optional<Users> adminOpt = usersRepository.findById(adminId);

		if (screenOpt.isEmpty())
			throw new Exception("Screen not found");
		if (adminOpt.isEmpty() || adminOpt.get().getRole() != Users.Role.ADMIN)
			throw new Exception("Unauthorized");
		Screens screen = screenOpt.get();
		screen.setIsActive(ActiveCodes.INACTIVE);
		screensRepository.save(screen);

		// Cascade: set all showtimes for this screen as INACTIVE
		List<Showtimes> showtimes = showtimesRepository.findByScreen_ScreenId(screenId);
		for (Showtimes showtime : showtimes) {
			showtime.setIsActive(ActiveCodes.INACTIVE);
			showtimesRepository.save(showtime);
		}

		logAudit("screens", screenId, "DELETE", adminId);

		return "Screen and associated showtimes marked as inactive.";
	}

	private ScreensDto convertToDto(Screens screen) {
		ScreensDto dto = new ScreensDto();
		dto.setScreenId(screen.getScreenId());
		dto.setScreenName(screen.getScreenName());
		dto.setCapacity(100);
		dto.setIsActive(screen.getIsActive());
		dto.setTheatreId(screen.getTheatre() != null ? screen.getTheatre().getTheaterId() : null);
		return dto;
	}

	private void logAudit(String tableName, Integer recordId, String action, Integer changedById) {
		AuditLogs audit = new AuditLogs();
		audit.setTableName(tableName);
		audit.setRecordId(recordId);
		try {
			ActionType actionType = ActionType.valueOf(action.toUpperCase());
			audit.setAction(actionType);
		} catch (IllegalArgumentException e) {
			throw new IllegalArgumentException("Invalid action type: " + action);
		}
		Users user = new Users();
		user.setUserId(changedById);
		audit.setChangedBy(user);
		audit.setChangedAt(new Timestamp(System.currentTimeMillis()));
		auditLogsRepository.save(audit);
	}

	public ScreensDto getScreenById(Integer screenId) throws Exception {
		Optional<Screens> screenOpt = screensRepository.findById(screenId);
		if (screenOpt.isEmpty() || screenOpt.get().getIsActive() != ActiveCodes.ACTIVE)
			throw new Exception("Screen not found");
		return convertToDto(screenOpt.get());
	}
}