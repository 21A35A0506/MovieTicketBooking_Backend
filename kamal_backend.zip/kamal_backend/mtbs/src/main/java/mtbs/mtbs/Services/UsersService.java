package mtbs.mtbs.Services;

import mtbs.mtbs.Model.Users;
import mtbs.mtbs.Enums.ActionType;
import mtbs.mtbs.Enums.ActiveCodes;
import mtbs.mtbs.Model.AuditLogs;
import mtbs.mtbs.Repository.UsersRepository;
import mtbs.mtbs.Repository.AuditLogsRepository;
import mtbs.mtbs.dto.UserDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UsersService {


    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private AuditLogsRepository auditLogsRepository;

    @Transactional
    public String registerUser(UserDto userDto) throws Exception {
        if (usersRepository.findByUsername(userDto.getUsername()).isPresent()) {
            throw new Exception("Username already exists!");
        }
        if (usersRepository.findByEmail(userDto.getEmail()).isPresent()) {
            throw new Exception("Email already registered!");
        }
        Users user = new Users();
        user.setUsername(userDto.getUsername());
        user.setPassword(Integer.toString(userDto.getPassword().hashCode()));
        user.setEmail(userDto.getEmail());
        user.setPhone(userDto.getPhone());
        user.setRole(userDto.getRole() != null ? userDto.getRole() : Users.Role.CUSTOMER);
        user.setIsActive(ActiveCodes.ACTIVE);
        user.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        user.setUpdatedAt(new Timestamp(System.currentTimeMillis()));

        usersRepository.save(user);

        logAudit("users", user.getUserId(), "INSERT", user.getUserId());

        return "User registered successfully!";
    }

    public UserDto loginUser(String username, String password) throws Exception {
        Optional<Users> userOpt = usersRepository.findByUsername(username);
        if (userOpt.isPresent()) {
            Users user = userOpt.get();
            
            if (Integer.parseInt(user.getPassword()) != (password.hashCode())) {
                throw new Exception("Invalid password");
            }
            else if (!user.getIsActive().equals(ActiveCodes.ACTIVE)) {
            	throw new Exception("User Account is deleted");
            }
            return convertToDto(user);
        } else {
            throw new Exception("User not found");
        }
    }

    public UserDto getUserById(Integer id) throws Exception {
        Optional<Users> userOpt = usersRepository.findById(id);
        if (userOpt.isPresent()) {
            return convertToDto(userOpt.get());
        } else {
            throw new Exception("User not found");
        }
    }

    @Transactional
    public String updateUser(Integer id, UserDto userDto) throws Exception {
        Optional<Users> userOpt = usersRepository.findById(id);
        if (userOpt.isPresent()) {
            Users user = userOpt.get();
            user.setUsername(userDto.getUsername());
            user.setEmail(userDto.getEmail());
            user.setPhone(userDto.getPhone());
            user.setPhone(userDto.getPhone());
            user.setPassword(Integer.toString(userDto.getPassword().hashCode()));
            // user.setRole(userDto.getRole() != null ? userDto.getRole() : Users.Role.CUSTOMER);
            // user.setIsActive(ActiveCodes.ACTIVE);
            user.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
            usersRepository.save(user);

            logAudit("users", id, "UPDATE", id);

            return "User updated successfully!";
        } else {
            throw new Exception("User not found");
        }
    }

    @Transactional
    public String deleteUser(Integer id) throws Exception {
        if (usersRepository.existsById(id)) {
            Optional<Users> userOpt = usersRepository.findById(id);
            Users user = userOpt.get();
            user.setIsActive(ActiveCodes.INACTIVE);
            usersRepository.save(user);

            logAudit("users", id, "DELETE", id);

            return "User deleted successfully!";
        } else {
            throw new Exception("User not found");
        }
    }

    public List<UserDto> getAllUsers() {
        return usersRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    private void logAudit(String tableName, Integer recordId, String action, Integer changedById) {
        AuditLogs audit = new AuditLogs();
        audit.setTableName(tableName);
        audit.setRecordId(recordId);

        try {
            ActionType actionType = ActionType.valueOf(action.toUpperCase());
            audit.setAction(actionType);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid action type: " + action);
        }
        Users user = new Users();
        user.setUserId(changedById);
        audit.setChangedBy(user);
        audit.setChangedAt(new Timestamp(System.currentTimeMillis()));
        auditLogsRepository.save(audit);
    }

    // Entity to DTO conversion
    private UserDto convertToDto(Users user) {
        UserDto dto = new UserDto();
        dto.setUserId(user.getUserId());
        dto.setUsername(user.getUsername());
        dto.setEmail(user.getEmail());
        dto.setPhone(user.getPhone());
        dto.setRole(user.getRole());
        dto.setCreatedAt(user.getCreatedAt());
        dto.setUpdatedAt(user.getUpdatedAt());
        return dto;
    }
}