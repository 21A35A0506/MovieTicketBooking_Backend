package mtbs.mtbs.Repository;

import mtbs.mtbs.Model.Theatres;
import mtbs.mtbs.Enums.ActiveCodes;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TheatresRepository extends JpaRepository<Theatres, Integer> {
    // Existing methods
    List<Theatres> findByCityIgnoreCase(String city);
    List<Theatres> findByLocationIgnoreCase(String location);
    List<Theatres> findByCityIgnoreCaseAndLocationIgnoreCase(String city, String location);

    // New method to get only ACTIVE/INACTIVE theatres
    List<Theatres> findByIsActive(ActiveCodes isActive);

    // Optionally, for more filtering:
    List<Theatres> findByCityIgnoreCaseAndIsActive(String city, ActiveCodes isActive);
    List<Theatres> findByLocationIgnoreCaseAndIsActive(String location, ActiveCodes isActive);
    List<Theatres> findByCityIgnoreCaseAndLocationIgnoreCaseAndIsActive(String city, String location, ActiveCodes isActive);
    
}
