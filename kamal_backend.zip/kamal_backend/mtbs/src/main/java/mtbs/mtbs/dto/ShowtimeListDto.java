package mtbs.mtbs.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class ShowtimeListDto {

    private Integer showtimeId;
    public LocalDateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	public LocalDateTime getEndTime() {
		return endTime;
	}

	public void setEndTime(LocalDateTime endTime) {
		this.endTime = endTime;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Integer getAvailableSeats() {
		return availableSeats;
	}

	public void setAvailableSeats(Integer availableSeats) {
		this.availableSeats = availableSeats;
	}

	public Integer getMovieId() {
		return movieId;
	}

	public void setMovieId(Integer movieId) {
		this.movieId = movieId;
	}

	public String getMovieTitle() {
		return movieTitle;
	}

	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}

	public Integer getScreenId() {
		return screenId;
	}

	public void setScreenId(Integer screenId) {
		this.screenId = screenId;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public Integer getTheatreId() {
		return theatreId;
	}

	public void setTheatreId(Integer theatreId) {
		this.theatreId = theatreId;
	}

	public String getTheatreName() {
		return theatreName;
	}

	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}

	public String getTheatreCity() {
		return theatreCity;
	}

	public void setTheatreCity(String theatreCity) {
		this.theatreCity = theatreCity;
	}

	private LocalDateTime startTime;
    private LocalDateTime endTime;
    private BigDecimal price;
    private Integer availableSeats;

    private Integer movieId;
    private String movieTitle;
    private String moviePosterUrl;  // renamed to match Angular

    private Integer screenId;
    private String screenName;

    private Integer theatreId;
    private String theatreName;
    private String theatreCity;
    
    private String seatsList;


    public String getSeatsList() {
        return seatsList;
    }

    public void setSeatsList(String seatsList) {
        this.seatsList = seatsList;
    }
    
    public ShowtimeListDto() {}

    public ShowtimeListDto(Integer showtimeId, LocalDateTime startTime, LocalDateTime endTime, BigDecimal price,
                           Integer availableSeats, Integer movieId, String movieTitle, String posterUrl,
                           Integer screenId, String screenName, Integer theatreId, String theatreName, String theatreCity, String seatsList) {
        this.setShowtimeId(showtimeId);
        this.startTime = startTime;
        this.endTime = endTime;
        this.price = price;
        this.availableSeats = availableSeats;
        this.movieId = movieId;
        this.movieTitle = movieTitle;
        this.moviePosterUrl = posterUrl; // updated here
        this.screenId = screenId;
        this.screenName = screenName;
        this.theatreId = theatreId;
        this.theatreName = theatreName;
        this.theatreCity = theatreCity;
        this.seatsList = seatsList;

    }

    // Getters and setters
    public String getMoviePosterUrl() { return moviePosterUrl; }
    public void setMoviePosterUrl(String moviePosterUrl) { this.moviePosterUrl = moviePosterUrl; }

	public Integer getShowtimeId() {
		return showtimeId;
	}

	public void setShowtimeId(Integer showtimeId) {
		this.showtimeId = showtimeId;
	}

    // ... keep all other getters/setters as they are
}