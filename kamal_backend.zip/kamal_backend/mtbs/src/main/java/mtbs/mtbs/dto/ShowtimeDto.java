package mtbs.mtbs.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import mtbs.mtbs.Enums.ActiveCodes;

public class ShowtimeDto {
    private Integer showtimeId;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private BigDecimal price;
    private Integer availableSeats;
    private Integer movieId;
    private String movieName;      // NEW
    private Integer screenId;
    private String screenName;     // NEW (optional, useful)
    private String theatreName;    // NEW
    private ActiveCodes isActive;
	private String seatsList;

	
    public String getSeatsList() {return seatsList; }
    public void setSeatsList(String seatsList) { this.seatsList = seatsList;}

    // Getters & Setters
    public Integer getShowtimeId() { return showtimeId; }
    public void setShowtimeId(Integer showtimeId) { this.showtimeId = showtimeId; }

    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }

    public LocalDateTime getEndTime() { return endTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }

    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }

    public Integer getAvailableSeats() { return availableSeats; }
    public void setAvailableSeats(Integer availableSeats) { this.availableSeats = availableSeats; }

    public Integer getMovieId() { return movieId; }
    public void setMovieId(Integer movieId) { this.movieId = movieId; }

    public String getMovieName() { return movieName; }
    public void setMovieName(String movieName) { this.movieName = movieName; }

    public Integer getScreenId() { return screenId; }
    public void setScreenId(Integer screenId) { this.screenId = screenId; }

    public String getScreenName() { return screenName; }
    public void setScreenName(String screenName) { this.screenName = screenName; }

    public String getTheatreName() { return theatreName; }
    public void setTheatreName(String theatreName) { this.theatreName = theatreName; }

    public ActiveCodes getIsActive() { return isActive; }
    public void setIsActive(ActiveCodes isActive) { this.isActive = isActive; }
}