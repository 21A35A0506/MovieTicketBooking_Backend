package mtbs.mtbs.dto;

import java.util.List;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class MovieTheatresDto {
    private Integer theatreId;
    private String theatreName;
    private String location;
    private String city;
    private List<ScreenWithShowtimes> screens;

    public static class ScreenWithShowtimes {
        private Integer screenId;
        private String screenName;
        private Integer capacity;
        private List<ShowtimeDto> showtimes;

        public ScreenWithShowtimes() {}
        public ScreenWithShowtimes(Integer screenId, String screenName, Integer capacity, List<ShowtimeDto> showtimes) {
            this.screenId = screenId;
            this.screenName = screenName;
            this.capacity = capacity;
            this.showtimes = showtimes;
        }

        public Integer getScreenId() { return screenId; }
        public void setScreenId(Integer screenId) { this.screenId = screenId; }

        public String getScreenName() { return screenName; }
        public void setScreenName(String screenName) { this.screenName = screenName; }

        public Integer getCapacity() { return capacity; }
        public void setCapacity(Integer capacity) { this.capacity = capacity; }

        public List<ShowtimeDto> getShowtimes() { return showtimes; }
        public void setShowtimes(List<ShowtimeDto> showtimes) { this.showtimes = showtimes; }
    }

    public MovieTheatresDto() {}
    public MovieTheatresDto(Integer theatreId, String theatreName, String location, String city, List<ScreenWithShowtimes> screens) {
        this.theatreId = theatreId;
        this.theatreName = theatreName;
        this.location = location;
        this.city = city;
        this.screens = screens;
    }

    public Integer getTheatreId() { return theatreId; }
    public void setTheatreId(Integer theatreId) { this.theatreId = theatreId; }

    public String getTheatreName() { return theatreName; }
    public void setTheatreName(String theatreName) { this.theatreName = theatreName; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public List<ScreenWithShowtimes> getScreens() { return screens; }
    public void setScreens(List<ScreenWithShowtimes> screens) { this.screens = screens; }
}
