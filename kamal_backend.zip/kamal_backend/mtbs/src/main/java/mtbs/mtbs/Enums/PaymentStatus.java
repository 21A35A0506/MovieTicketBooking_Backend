package mtbs.mtbs.Enums;

public enum PaymentStatus {
    PENDING, COMPLETED, FAILED, REFUNDED
}