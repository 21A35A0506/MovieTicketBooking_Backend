package mtbs.mtbs.Controller;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;

import jakarta.servlet.http.HttpServletResponse;
import mtbs.mtbs.Model.Bookings;
import mtbs.mtbs.Services.BookingsService;
import mtbs.mtbs.dto.BookingDto;
import mtbs.mtbs.dto.BookingWithShowtimeDto;

@RestController
@CrossOrigin(origins="http://localhost:4200/")
@RequestMapping("/api/bookings")
public class BookingsController {

    @Autowired
    private BookingsService bookingsService;

    @PostMapping("/create")
    public ResponseEntity<?> createBooking(
            @RequestParam Integer userId,
            @RequestParam Integer showtimeId,
            @RequestBody List<String> seatNumbers) {
        try {
            BookingDto confirmation = bookingsService.createBooking(userId, showtimeId, seatNumbers);
            return ResponseEntity.ok(confirmation);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getBookingsByUser(@PathVariable Integer userId) {
        try {
            return ResponseEntity.ok(bookingsService.getBookingsByUser(userId));
        } catch (Exception e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }

    @GetMapping("/")
    public ResponseEntity<List<BookingDto>> getAllBookings() {
        return ResponseEntity.ok(bookingsService.getAllBookings());
    }

    @GetMapping("/getRangeBookings")
    public ResponseEntity<?> getAllBookingsRange(
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to) {
        try {
            return ResponseEntity.ok(bookingsService.getAllBookingsRange(from, to));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // New APIs for BookingWithShowtimeDto
    @GetMapping("/with-showtime")
    public ResponseEntity<List<BookingWithShowtimeDto>> getAllBookingsWithShowtime() {
        return ResponseEntity.ok(bookingsService.getAllBookingswithoutfilter());
    }

    @GetMapping("/with-showtime/range")
    public ResponseEntity<?> getAllBookingsWithShowtimeRange(
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to) {
        try {
//            Timestamp fromTs = (from != null) ? Timestamp.valueOf(from + " 00:00:00") : null;
//            Timestamp toTs = (to != null) ? Timestamp.valueOf(to + " 23:59:59") : null;
            return ResponseEntity.ok(bookingsService.getAllBookingsRange(from, to));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Invalid date format. Use yyyy-MM-dd");
        }
    }
    
    @GetMapping("/export")
    public void exportBookingsToCsv(HttpServletResponse response) throws IOException {
        response.setContentType("text/csv");

        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        String currentDateTime = dateFormatter.format(new Date());

        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=bookings_" + currentDateTime + ".csv";
        response.setHeader(headerKey, headerValue);

        String csvData = bookingsService.generateBookingsCsv();
        response.getWriter().write(csvData);
        response.getWriter().flush();
    }


    @PutMapping("/{bookingId}/cancel")
    public ResponseEntity<?> cancelBooking(
            @PathVariable Integer bookingId,
            @RequestParam Integer userId) {
        try {
            String res = bookingsService.cancelBooking(bookingId, userId);
            return ResponseEntity.ok(res);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PutMapping("/{bookingId}/payment-status")
    public ResponseEntity<?> updatePaymentStatus(
            @PathVariable Integer bookingId,
            @RequestParam String status,
            @RequestParam Integer adminId) {
        try {
            Bookings.PaymentStatus paymentStatus = Bookings.PaymentStatus.valueOf(status.toUpperCase());
            String res = bookingsService.updatePaymentStatus(bookingId, paymentStatus, adminId);
            return ResponseEntity.ok(res);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
    
    @PutMapping("/{bookingId}/status")
    public ResponseEntity<?> updateStatus(
            @PathVariable Integer bookingId,
            @RequestParam String status,
            @RequestParam Integer adminId) {
        try {
            Bookings.BookingStatus stat = Bookings.BookingStatus.valueOf(status.toUpperCase());
            String res = bookingsService.updateStatus(bookingId, stat, adminId);
            return ResponseEntity.ok(res);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    
    @GetMapping("/{bookingId}/details")
    public ResponseEntity<List<BookingDto>> getBookingDetails(@PathVariable Integer bookingId) {
        return ResponseEntity.ok(bookingsService.getBookingDetails(bookingId));
    }

}