package mtbs.mtbs.Repository;

import mtbs.mtbs.Model.Movies;
import mtbs.mtbs.Enums.ActiveCodes;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MoviesRepository extends JpaRepository<Movies, Integer> {
    List<Movies> findByIsActive(ActiveCodes status);
    List<Movies> findByGenreIgnoreCaseAndIsActive(String genre, ActiveCodes status);
    List<Movies> findByLanguageIgnoreCaseAndIsActive(String language, ActiveCodes status);
    List<Movies> findByGenreIgnoreCaseAndLanguageIgnoreCaseAndIsActive(String genre, String language, ActiveCodes status);
    List<Movies> findByTitleIgnoreCaseAndIsActive(String title, ActiveCodes status);
}
