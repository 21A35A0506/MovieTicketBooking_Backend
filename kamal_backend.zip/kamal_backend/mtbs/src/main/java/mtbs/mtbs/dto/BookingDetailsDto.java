package mtbs.mtbs.dto;

import java.sql.Timestamp;
import java.util.List;

public class BookingDetailsDto {

    private Integer bookingId;
    private String movieName;
    private Timestamp showtimeStartTime;
    private Integer userId;
    private String username;
    private String email;
    private List<String> seatNumbers;
    private Integer seatCount;
    private Timestamp bookingDate;

    public BookingDetailsDto() {}

    public BookingDetailsDto(Integer bookingId, String movieName, Timestamp showtimeStartTime,
                             Integer userId, String username, String email,
                             List<String> seatNumbers, Integer seatCount, Timestamp bookingDate) {
        this.bookingId = bookingId;
        this.movieName = movieName;
        this.showtimeStartTime = showtimeStartTime;
        this.userId = userId;
        this.username = username;
        this.email = email;
        this.seatNumbers = seatNumbers;
        this.seatCount = seatCount;
        this.bookingDate = bookingDate;
    }

    // Getters and setters

    public Integer getBookingId() {
        return bookingId;
    }

    public void setBookingId(Integer bookingId) {
        this.bookingId = bookingId;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public Timestamp getShowtimeStartTime() {
        return showtimeStartTime;
    }

    public void setShowtimeStartTime(Timestamp showtimeStartTime) {
        this.showtimeStartTime = showtimeStartTime;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<String> getSeatNumbers() {
        return seatNumbers;
    }

    public void setSeatNumbers(List<String> seatNumbers) {
        this.seatNumbers = seatNumbers;
    }

    public Integer getSeatCount() {
        return seatCount;
    }

    public void setSeatCount(Integer seatCount) {
        this.seatCount = seatCount;
    }

    public Timestamp getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(Timestamp bookingDate) {
        this.bookingDate = bookingDate;
    }
}
