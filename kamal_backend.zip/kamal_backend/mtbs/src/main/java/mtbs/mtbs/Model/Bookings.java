package mtbs.mtbs.Model;

import jakarta.persistence.*;
import mtbs.mtbs.Model.Bookings.BookingStatus;
import mtbs.mtbs.Model.Bookings.PaymentStatus;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
@Entity
@Table(name = "bookings")
public class Bookings {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "booking_id")
	private Integer bookingId;

	@ManyToOne()
	@JoinColumn(name = "user_id", nullable = false)
	private Users user;

	@ManyToOne()
	@JsonIgnore
	@JoinColumn(name = "showtime_id", nullable = false)
	private Showtimes showtime;

	@Column(name = "booking_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Timestamp bookingDate;

	@Column(name = "total_amount", nullable = false, precision = 10, scale = 2)
	private BigDecimal totalAmount;

	@Enumerated(EnumType.STRING)
	@Column(name = "status", nullable = false, length = 10)
	private BookingStatus status; // 'CONFIRMED','CANCELLED','COMPLETED'

	@Enumerated(EnumType.STRING)
	@Column(name = "payment_status", nullable = false, length = 10)
	private PaymentStatus paymentStatus; // 'PENDING','COMPLETED','FAILED','REFUNDED'

	@Column(name = "created_at", nullable = false, updatable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Timestamp createdAt;

	@Column(name = "updated_at", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
	private Timestamp updatedAt;

	@OneToMany(mappedBy = "booking", cascade = CascadeType.ALL)
	private Set<BookingSeats> bookingSeats;

	// Enums for booking and payment status
	public enum BookingStatus {
		CONFIRMED, CANCELLED, COMPLETED
	}

	public enum PaymentStatus {
		PENDING, COMPLETED, FAILED, REFUNDED
	}

	// Constructors
	public Bookings() {
	}

	public Bookings(Users user, Showtimes showtime, BigDecimal totalAmount, BookingStatus status,
			PaymentStatus paymentStatus) {
		this.user = user;
		this.showtime = showtime;
		this.totalAmount = totalAmount;
		this.status = status;
		this.paymentStatus = paymentStatus;
	}


	// Getters and Setters
	public Integer getBookingId() {
		return bookingId;
	}

	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	public Showtimes getShowtime() {
		return showtime;
	}

	public void setShowtime(Showtimes showtime) {
		this.showtime = showtime;
	}

	public Timestamp getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(Timestamp bookingDate) {
		this.bookingDate = bookingDate;
	}

	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}

	public BookingStatus getStatus() {
		return status;
	}

	public void setStatus(BookingStatus status) {
		this.status = status;
	}

	public PaymentStatus getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(PaymentStatus paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public Timestamp getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	public Timestamp getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Set<BookingSeats> getBookingSeats() {
		return bookingSeats;
	}

	public void setBookingSeats(Set<BookingSeats> bookingSeats) {
		this.bookingSeats = bookingSeats;
	}
}
