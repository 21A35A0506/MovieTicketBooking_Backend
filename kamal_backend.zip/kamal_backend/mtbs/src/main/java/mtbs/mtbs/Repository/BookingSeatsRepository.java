package mtbs.mtbs.Repository;

import mtbs.mtbs.Model.BookingSeats;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookingSeatsRepository extends JpaRepository<BookingSeats, Integer> {
    List<BookingSeats> findByBooking_BookingId(Integer bookingId);
}
