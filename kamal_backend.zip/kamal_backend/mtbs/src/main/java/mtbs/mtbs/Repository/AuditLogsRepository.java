package mtbs.mtbs.Repository;

import mtbs.mtbs.Model.AuditLogs;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AuditLogsRepository extends JpaRepository<AuditLogs, Integer> {
    List<AuditLogs> findByTableNameIgnoreCase(String tableName);
    List<AuditLogs> findByRecordId(Integer recordId);
    List<AuditLogs> findByChangedBy_UserId(Integer userId);
}
