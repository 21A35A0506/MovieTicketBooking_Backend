package mtbs.mtbs.Controller;

import mtbs.mtbs.dto.TheatreDto;
import mtbs.mtbs.dto.TheatreShowtimeDto;
import mtbs.mtbs.Services.TheatresService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins="http://localhost:4200/")
@RequestMapping("/api/theatres")
public class TheatresController {

    @Autowired
    private TheatresService theatresService;

    @PostMapping("/add")
    public ResponseEntity<?> addTheatre(@RequestBody TheatreDto dto, @RequestParam("adminId") Integer adminId) {
        try {
            String res = theatresService.addTheatre(dto, adminId);
            return ResponseEntity.ok(res);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/")
    public ResponseEntity<List<TheatreDto>> getAllTheatres() {
        return ResponseEntity.ok(theatresService.getAllTheatres());
    }

    @GetMapping("/search")
    public ResponseEntity<List<TheatreDto>> searchTheatres(
            @RequestParam(required = false) String city,
            @RequestParam(required = false) String location
    ) {
        return ResponseEntity.ok(theatresService.searchTheatres(city, location));
    }

    @GetMapping("/{theatreId}")
    public ResponseEntity<?> getTheatreById(@PathVariable Integer theatreId) {
        try {
            TheatreDto dto = theatresService.getTheatreById(theatreId);
            return ResponseEntity.ok(dto);
        } catch (Exception e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }
    
    @GetMapping("/{theatreId}/showtimes")
    public ResponseEntity<TheatreShowtimeDto> getTheatreShowtimes(@PathVariable Integer theatreId) {
        try {
            TheatreShowtimeDto dto = theatresService.getTheatreShowtimes(theatreId);
            return ResponseEntity.ok(dto);
        } catch (Exception ex) {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{theatreId}/update")
    public ResponseEntity<?> updateTheatre(
            @PathVariable Integer theatreId,
            @RequestBody TheatreDto updatedDto,
            @RequestParam("adminId") Integer adminId
    ) {
        try {
            String res = theatresService.updateTheatre(theatreId, updatedDto, adminId);
            return ResponseEntity.ok(res);
        } catch (Exception e) {
            if (e.getMessage().equals("Theatre not found")) {
                return ResponseEntity.status(404).body(e.getMessage());
            } else {
                return ResponseEntity.badRequest().body(e.getMessage());
            }
        }
    }

    @DeleteMapping("/{theatreId}/delete")
    public ResponseEntity<?> deleteTheatre(
            @PathVariable Integer theatreId,
            @RequestParam("adminId") Integer adminId
    ) {
        try {
            String res = theatresService.deleteTheatre(theatreId, adminId);
            return ResponseEntity.ok(res);
        } catch (Exception e) {
            if (e.getMessage().equals("Theatre not found")) {
                return ResponseEntity.status(404).body(e.getMessage());
            } else {
                return ResponseEntity.badRequest().body(e.getMessage());
            }
        }
    }
}
