package mtbs.mtbs.Controller;

import mtbs.mtbs.dto.MovieDto;
import mtbs.mtbs.dto.MovieTheatresDto;
import mtbs.mtbs.dto.MovieWithShowtimesDto;
import mtbs.mtbs.Services.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins="http://localhost:4200/")
@RequestMapping("/api/movies")
public class MoviesController {

    @Autowired
    private MovieService movieService;

    @PostMapping("/add")
    public ResponseEntity<?> addMovie(@RequestBody MovieDto dto, @RequestParam Integer adminId) {
        try {
            String res = movieService.addMovie(dto, adminId);
            return ResponseEntity.ok(res);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/")
    public ResponseEntity<List<MovieDto>> getAllMovies() {
        return ResponseEntity.ok(movieService.getAllMovies());
    }

    @GetMapping("/search")
    public ResponseEntity<List<MovieDto>> searchMovies(
            @RequestParam(required = false) String genre,
            @RequestParam(required = false) String language
    ) {
        return ResponseEntity.ok(movieService.searchMovies(genre, language));
    }

    @GetMapping("/searchTitle")
    public ResponseEntity<?> searchMoviesByName(@RequestParam String title) {
        try {
            List<MovieDto> dtos = movieService.getMoviesByName(title);
            return ResponseEntity.ok(dtos);
        } catch (Exception e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }
    
    @GetMapping("/searchDetails")
    public ResponseEntity<?> searchMovieDetails(@RequestParam Integer movieId) {
        try {
            MovieWithShowtimesDto dto = movieService.getMovieWithShowtimesById(movieId);
            return ResponseEntity.ok(dto);
        } catch (Exception e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }



    @GetMapping("/{movieId}")
    public ResponseEntity<?> getMovieById(@PathVariable Integer movieId) {
        try {
            MovieDto dto = movieService.getMovieById(movieId);
            return ResponseEntity.ok(dto);
        } catch (Exception e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }

    @PutMapping("/{movieId}/update")
    public ResponseEntity<?> updateMovie(@PathVariable Integer movieId, @RequestBody MovieDto dto, @RequestParam Integer adminId) {
        try {
            String res = movieService.updateMovie(movieId, dto, adminId);
            return ResponseEntity.ok(res);
        } catch (Exception e) {
            if (e.getMessage().equals("Movie not found")) {
                return ResponseEntity.status(404).body(e.getMessage());
            }
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/{movieId}/delete")
    public ResponseEntity<?> deleteMovie(@PathVariable Integer movieId, @RequestParam Integer adminId) {
        try {
            String res = movieService.deleteMovie(movieId, adminId);
            return ResponseEntity.ok(res);
        } catch (Exception e) {
            if (e.getMessage().equals("Movie not found")) {
                return ResponseEntity.status(404).body(e.getMessage());
            }
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
    
    
    @GetMapping("/{movieId}/theatres")
    public ResponseEntity<List<MovieTheatresDto>> getTheatresScreensShowtimesForMovie(@PathVariable Integer movieId) {
        List<MovieTheatresDto> result = movieService.getTheatresScreensShowtimesForMovie(movieId);
        return ResponseEntity.ok(result);
    }
    
    @GetMapping("/{movieId}/theatres/{theatreId}/screens")
    public ResponseEntity<MovieTheatresDto> getScreensShowtimesForMovieAndTheatre(
        @PathVariable Integer movieId,
        @PathVariable Integer theatreId
    ) {
        MovieTheatresDto result = movieService.getScreensShowtimesForMovieAndTheatre(movieId, theatreId);
        return ResponseEntity.ok(result);
    }

}
