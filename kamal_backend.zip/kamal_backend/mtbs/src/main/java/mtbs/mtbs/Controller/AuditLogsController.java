package mtbs.mtbs.Controller;

import mtbs.mtbs.dto.AuditLogsDto;
import mtbs.mtbs.Services.AuditLogsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins="http://localhost:4200/")
@RequestMapping("/api/audit-logs")
public class AuditLogsController {

    @Autowired
    private AuditLogsService auditLogsService;

    @GetMapping("/")
    public ResponseEntity<?> getAllLogs(@RequestParam Integer adminId) {
        try {
            List<AuditLogsDto> logs = auditLogsService.getAllLogs(adminId);
            return ResponseEntity.ok(logs);
        } catch (SecurityException e) {
            return ResponseEntity.status(403).body(e.getMessage());
        }
    }

    @GetMapping("/table/{tableName}")
    public ResponseEntity<?> getLogsByTable(@PathVariable String tableName, @RequestParam Integer adminId) {
        try {
            List<AuditLogsDto> logs = auditLogsService.getLogsByTable(tableName, adminId);
            return ResponseEntity.ok(logs);
        } catch (SecurityException e) {
            return ResponseEntity.status(403).body(e.getMessage());
        }
    }

    @GetMapping("/record/{recordId}")
    public ResponseEntity<?> getLogsByRecord(@PathVariable Integer recordId, @RequestParam Integer adminId) {
        try {
            List<AuditLogsDto> logs = auditLogsService.getLogsByRecord(recordId, adminId);
            return ResponseEntity.ok(logs);
        } catch (SecurityException e) {
            return ResponseEntity.status(403).body(e.getMessage());
        }
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getLogsByUser(@PathVariable Integer userId, @RequestParam Integer adminId) {
        try {
            List<AuditLogsDto> logs = auditLogsService.getLogsByUser(userId, adminId);
            return ResponseEntity.ok(logs);
        } catch (SecurityException e) {
            return ResponseEntity.status(403).body(e.getMessage());
        }
    }
}
