package mtbs.mtbs.Model;

import jakarta.persistence.*;
import mtbs.mtbs.Enums.ActiveCodes;

import java.sql.Timestamp;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "theaters")
public class Theatres {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "theater_id")
    private Integer theaterId;

    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Column(name = "location", nullable = false, length = 255)
    private String location;

    @Column(name = "city", nullable = false, length = 50)
    private String city;

    @Column(name = "capacity", nullable = false)
    private Integer capacity;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "is_active", nullable = false)
    private ActiveCodes isActive;

	@ManyToOne(fetch = FetchType.LAZY)
    @JsonIgnore    
    @JoinColumn(name = "created_by", nullable = false)
    private Users createdBy;

    @Column(name = "created_at", nullable = false, updatable = false,
            columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp createdAt;

    @Column(name = "updated_at", nullable = false,
            columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    private Timestamp updatedAt;

    @OneToMany(mappedBy = "theatre", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JsonIgnore
    private Set<Screens> screens;

    // Constructors
    public Theatres() {}

    public Theatres(String name, String location, String city, Integer capacity, Users createdBy) {
        this.name = name;
        this.location = location;
        this.city = city;
        this.capacity = capacity;
        this.createdBy = createdBy;
    }

    // Getters and Setters
    public Integer getTheaterId() { return theaterId; }
    public void setTheaterId(Integer theaterId) { this.theaterId = theaterId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    
    public ActiveCodes getIsActive() {
		return isActive;
	}

	public void setIsActive(ActiveCodes isActive) {
		this.isActive = isActive;
	}
    public Integer getCapacity() { return capacity; }
    public void setCapacity(Integer capacity) { this.capacity = capacity; }

    public Users getCreatedBy() { return createdBy; }
    public void setCreatedBy(Users createdBy) { this.createdBy = createdBy; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public Timestamp getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Timestamp updatedAt) { this.updatedAt = updatedAt; }

    public Set<Screens> getScreens() { return screens; }
    public void setScreens(Set<Screens> screens) { this.screens = screens; }
}
