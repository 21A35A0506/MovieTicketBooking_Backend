package mtbs.mtbs.Model;

import jakarta.persistence.*;
import mtbs.mtbs.Enums.ActiveCodes;

import java.sql.Timestamp;
import java.util.Set;

@Entity
@Table(name = "screens")
public class Screens {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "screen_id")
    private Integer screenId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "theater_id", nullable = false)
    private Theatres theatre;

    @Column(name = "screen_name", nullable = false, length = 50)
    private String screenName;

    @Column(name = "capacity", nullable = false)
    private Integer capacity;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "is_active", nullable = false)
    private ActiveCodes isActive;

    @Column(name = "created_at", nullable = false, updatable = false,
            columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp createdAt;

    @Column(name = "updated_at", nullable = false,
            columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    private Timestamp updatedAt;

    @OneToMany(mappedBy = "screen", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private Set<Showtimes> showtimes;
    
//    @Column(name = "seats_list", columnDefinition = "TEXT", nullable = false)
//    private String seatsList;
//
//    public String getSeatsList() {
//        return seatsList;
//    }
//
//    public void setSeatsList(String seatsList) {
//        this.seatsList = seatsList;
//    }

    // Constructors
    public Screens() {}

    public Screens(Theatres theatre, String screenName, Integer capacity) {
        this.theatre = theatre;
        this.screenName = screenName;
        this.capacity = capacity;
    }

    // Getters and Setters
    public Integer getScreenId() { return screenId; }
    public void setScreenId(Integer screenId) { this.screenId = screenId; }

    public Theatres getTheatre() { return theatre; }
    public void setTheatre(Theatres theatre) { this.theatre = theatre; }

    public String getScreenName() { return screenName; }
    public void setScreenName(String screenName) { this.screenName = screenName; }

    public Integer getCapacity() { return capacity; }
    public void setCapacity(Integer capacity) { this.capacity = capacity; }
    
    public ActiveCodes getIsActive() { return isActive; }
    public void setIsActive(ActiveCodes isActive) { this.isActive = isActive; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public Timestamp getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Timestamp updatedAt) { this.updatedAt = updatedAt; }

    public Set<Showtimes> getShowtimes() { return showtimes; }
    public void setShowtimes(Set<Showtimes> showtimes) { this.showtimes = showtimes; }
}
