package mtbs.mtbs.Services;

import mtbs.mtbs.Model.BookingSeats;
import mtbs.mtbs.Repository.BookingSeatsRepository;
import mtbs.mtbs.dto.BookingSeatDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BookingSeatsService {

    @Autowired
    private BookingSeatsRepository bookingSeatsRepository;

    // Get seats by booking ID (return as DTOs)
    public List<BookingSeatDto> getSeatsByBooking(Integer bookingId) {
        return bookingSeatsRepository.findByBooking_BookingId(bookingId)
                .stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    // Get all booking seats (return as DTOs)
    public List<BookingSeatDto> getAllBookingSeats() {
        return bookingSeatsRepository.findAll()
                .stream()
                .map(this::convertToDto) 	
                .collect(Collectors.toList());
    }

    // Entity to DTO converter
    private BookingSeatDto convertToDto(BookingSeats seat) {
        BookingSeatDto dto = new BookingSeatDto();
        dto.setBookingSeatId(seat.getBookingSeatId());
        dto.setBookingId(seat.getBooking() != null ? seat.getBooking().getBookingId() : null);
        dto.setSeatNumber(seat.getSeatNumber());
        dto.setPrice(seat.getPrice());
        return dto;
    }

    // (Optional) add and delete methods using BookingSeatDto as needed
}
