package mtbs.mtbs.Services;

import mtbs.mtbs.Enums.ActionType;
import mtbs.mtbs.Enums.ActiveCodes;
import mtbs.mtbs.Model.*;
import mtbs.mtbs.Repository.*;
import mtbs.mtbs.dto.ScreenTheatreDto;
import mtbs.mtbs.dto.ShowtimeDto;
import mtbs.mtbs.dto.ShowtimeListDto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ShowtimesService {

	@Autowired
	private ShowtimesRepository showtimesRepository;

	@Autowired
	private MoviesRepository moviesRepository;

	@Autowired
	private ScreensRepository screensRepository;

	@Autowired
	private UsersRepository usersRepository;

	@Autowired
	private AuditLogsRepository auditLogsRepository;

	private ObjectMapper objectMapper = new ObjectMapper();


	public Map<String, String[]> parseSeatsString(String seatsList) {
	    try {
	        // Use TypeReference to specify the correct map type with generic types
	        return objectMapper.readValue(seatsList, new TypeReference<Map<String, String[]>>() {});
	    } catch (Exception e) {
	        // Handle any exceptions during parsing (e.g., malformed JSON)
	        e.printStackTrace();
	        return null;
	    }
	}


	// Converts the seat map back into a JSON string
	public String convertSeatsMapToJson(Map<String, String[]> seatMap) {
		try {
			// Convert the Map to a JSON string
			return objectMapper.writeValueAsString(seatMap);
		} catch (Exception e) {
			// Handle any exceptions during conversion
			e.printStackTrace();
			return "{}";
		}
	}

	private String generateDefaultSeatsJson() {
		StringBuilder sb = new StringBuilder();
		sb.append("{");
		char row = 'A';
		for (int i = 0; i < 5; i++, row++) {
			sb.append("\"").append(row).append("\":[");
			for (int seat = 0; seat < 20; seat++) {
				sb.append("\"available\"");
				if (seat < 19)
					sb.append(",");
			}
			sb.append("]");
			if (i < 4)
				sb.append(",");
		}
		sb.append("}");
		return sb.toString();
	}

	
	@Transactional
	public String addShowtime(ShowtimeDto dto, Integer adminId) throws Exception {
		Optional<Movies> movieOpt = moviesRepository.findById(dto.getMovieId());
		Optional<Screens> screenOpt = screensRepository.findById(dto.getScreenId());
		Optional<Users> adminOpt = usersRepository.findById(adminId);

		if (movieOpt.isEmpty() || screenOpt.isEmpty() || adminOpt.isEmpty()
				|| adminOpt.get().getRole() != Users.Role.ADMIN) {
			throw new Exception("Invalid IDs or unauthorized.");
		}

		Showtimes showtime = new Showtimes();
		showtime.setStartTime(dto.getStartTime());
		showtime.setEndTime(dto.getEndTime());
		showtime.setPrice(dto.getPrice());
		showtime.setAvailableSeats(dto.getAvailableSeats());
		showtime.setMovie(movieOpt.get());
		showtime.setScreen(screenOpt.get());
		showtime.setCreatedBy(adminOpt.get());
		showtime.setIsActive(ActiveCodes.ACTIVE);
		showtime.setCreatedAt(new Timestamp(System.currentTimeMillis()));
		showtime.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
		showtime.setSeatsList(generateDefaultSeatsJson());

		showtimesRepository.save(showtime);

		logAudit("showtimes", showtime.getShowtimeId(), "INSERT", adminId);

		return "Showtime added successfully!";
	}

	// Only ACTIVE showtimes for general queries
	public List<ShowtimeDto> getAllShowtimes() {
		return showtimesRepository.findByIsActive(ActiveCodes.ACTIVE).stream().map(this::convertToDto)
				.collect(Collectors.toList());
	}

	public List<ShowtimeListDto> getAllShowtimeListDtos() {
		return showtimesRepository.findByIsActive(ActiveCodes.ACTIVE).stream().map(this::convertToShowtimeListDto)
				.collect(Collectors.toList());
	}

	public List<ShowtimeDto> searchShowtimes(Integer movieId, String movieName, Integer screenId, String theatreName, String date) {
		List<Showtimes> showtimes;
		if (movieId != null && screenId != null && date != null) {
			LocalDate searchDate = LocalDate.parse(date);
			showtimes = showtimesRepository.findByMovie_MovieIdAndScreen_ScreenIdAndStartTimeBetweenAndIsActive(movieId,
					screenId, searchDate.atStartOfDay(), searchDate.plusDays(1).atStartOfDay(), ActiveCodes.ACTIVE);
		} else if (movieId != null) {
			showtimes = showtimesRepository.findByMovie_MovieIdAndIsActive(movieId, ActiveCodes.ACTIVE);
		} else if (screenId != null) {
			showtimes = showtimesRepository.findByScreen_ScreenIdAndIsActive(screenId, ActiveCodes.ACTIVE);
		} else if (date != null) {
			LocalDate searchDate = LocalDate.parse(date);
			showtimes = showtimesRepository.findByStartTimeBetweenAndIsActive(searchDate.atStartOfDay(),
					searchDate.plusDays(1).atStartOfDay(), ActiveCodes.ACTIVE);
		} else {
			showtimes = showtimesRepository.findByIsActive(ActiveCodes.ACTIVE);
		}
		return showtimes.stream().map(this::convertToDto).collect(Collectors.toList());
	}

	@Transactional
	public String updateShowtime(Integer showtimeId, ShowtimeDto updatedDto, Integer adminId) throws Exception {
		Optional<Showtimes> showtimeOpt = showtimesRepository.findById(showtimeId);
		Optional<Users> adminOpt = usersRepository.findById(adminId);
		if (showtimeOpt.isEmpty())
			throw new Exception("Showtime not found");
		if (adminOpt.isEmpty() || adminOpt.get().getRole() != Users.Role.ADMIN)
			throw new Exception("Only admins can update showtimes.");

		Showtimes showtime = showtimeOpt.get();
		showtime.setStartTime(updatedDto.getStartTime());
		showtime.setEndTime(updatedDto.getEndTime());
		showtime.setPrice(updatedDto.getPrice());
		showtime.setAvailableSeats(updatedDto.getAvailableSeats());
		showtime.setIsActive(updatedDto.getIsActive());
		showtime.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
		showtime.setSeatsList(updatedDto.getSeatsList());

		showtimesRepository.save(showtime);

		logAudit("showtimes", showtimeId, "UPDATE", adminId);

		return "Showtime updated successfully!";
	}

	// SOFT DELETE implementation
	@Transactional
	public String deleteShowtime(Integer showtimeId, Integer adminId) throws Exception {
		Optional<Showtimes> showtimeOpt = showtimesRepository.findById(showtimeId);
		Optional<Users> adminOpt = usersRepository.findById(adminId);
		if (showtimeOpt.isEmpty())
			throw new Exception("Showtime not found");
		if (adminOpt.isEmpty() || adminOpt.get().getRole() != Users.Role.ADMIN)
			throw new Exception("Only admins can delete showtimes.");
		Showtimes showtime = showtimeOpt.get();
		showtime.setIsActive(ActiveCodes.INACTIVE);
		showtimesRepository.save(showtime);

		logAudit("showtimes", showtimeId, "DELETE", adminId);

		return "Showtime marked as inactive.";
	}

	private ShowtimeDto convertToDto(Showtimes showtime) {
	    ShowtimeDto dto = new ShowtimeDto();
	    dto.setShowtimeId(showtime.getShowtimeId());
	    dto.setStartTime(showtime.getStartTime());
	    dto.setEndTime(showtime.getEndTime());
	    dto.setPrice(showtime.getPrice());
	    dto.setAvailableSeats(showtime.getAvailableSeats());
		dto.setSeatsList(showtime.getSeatsList());

	    // Movie
	    if (showtime.getMovie() != null) {
	        dto.setMovieId(showtime.getMovie().getMovieId());
	        dto.setMovieName(showtime.getMovie().getTitle());   // NEW
	    }

	    // Screen & Theatre
	    if (showtime.getScreen() != null) {
	        dto.setScreenId(showtime.getScreen().getScreenId());
	        dto.setScreenName(showtime.getScreen().getScreenName()); // NEW

	        if (showtime.getScreen().getTheatre() != null) {
	            dto.setTheatreName(showtime.getScreen().getTheatre().getName()); // NEW
	        }
	    }

	    dto.setIsActive(showtime.getIsActive());

	    return dto;
	}


	private ShowtimeListDto convertToShowtimeListDto(Showtimes showtime) {
	    Movies movie = showtime.getMovie();
	    Screens screen = showtime.getScreen();
	    Theatres theatre = screen.getTheatre();

	    return new ShowtimeListDto(
	        showtime.getShowtimeId(),
	        showtime.getStartTime(),
	        showtime.getEndTime(),
	        showtime.getPrice(),
	        showtime.getAvailableSeats(),
	        movie.getMovieId(),
	        movie.getTitle(),
	        movie.getPosterUrl(), // mapped to moviePosterUrl
	        screen.getScreenId(),
	        screen.getScreenName(),
	        theatre.getTheaterId(),
	        theatre.getName(),
	        theatre.getCity(),
	        showtime.getSeatsList()
	    );
	}


    public ShowtimeDto getUserById(Integer id) throws Exception {
        Optional<Showtimes> userOpt = showtimesRepository.findById(id);
        if (userOpt.isPresent()) {
            return convertToDto(userOpt.get());
        } else {
            throw new Exception("Show not found");
        }
    }

	public List<ScreenTheatreDto> getAllScreensWithTheatreInfo() {
	    // Fetch all active screens (optionally filter by active status if needed)
	    List<Screens> screens = screensRepository.findAll();  // or findByIsActive(ActiveCodes.ACTIVE);

	    return screens.stream()
	        .filter(screen -> screen.getTheatre() != null)  // filter out null theatres if any
	        .map(screen -> new ScreenTheatreDto(
	            screen.getScreenId(),
	            screen.getScreenName(),
	            screen.getTheatre().getName()
	        ))
	        .collect(Collectors.toList());
	}


	private void logAudit(String tableName, Integer recordId, String action, Integer changedById) {
		AuditLogs audit = new AuditLogs();
		audit.setTableName(tableName);
		audit.setRecordId(recordId);
		try {
			ActionType actionType = ActionType.valueOf(action.toUpperCase());
			audit.setAction(actionType);
		} catch (IllegalArgumentException e) {
			throw new IllegalArgumentException("Invalid action type: " + action);
		}
		Users user = new Users();
		user.setUserId(changedById);
		audit.setChangedBy(user);
		audit.setChangedAt(new Timestamp(System.currentTimeMillis()));
		auditLogsRepository.save(audit);
	}
}