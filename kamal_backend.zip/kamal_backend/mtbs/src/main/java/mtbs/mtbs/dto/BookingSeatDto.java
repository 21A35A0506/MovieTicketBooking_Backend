package mtbs.mtbs.dto;

import java.math.BigDecimal;

public class BookingSeatDto {
    private Integer bookingSeatId;
    private Integer bookingId;
    private String seatNumber;
    private BigDecimal price;

    public Integer getBookingSeatId() {
        return bookingSeatId;
    }
    public void setBookingSeatId(Integer bookingSeatId) {
        this.bookingSeatId = bookingSeatId;
    }

    public Integer getBookingId() {
        return bookingId;
    }
    public void setBookingId(Integer bookingId) {
        this.bookingId = bookingId;
    }

    public String getSeatNumber() {
        return seatNumber;
    }
    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
    }

    public BigDecimal getPrice() {
        return price;
    }
    public void setPrice(BigDecimal price) {
        this.price = price;
    }
}
