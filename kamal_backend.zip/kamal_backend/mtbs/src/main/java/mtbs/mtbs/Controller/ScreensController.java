package mtbs.mtbs.Controller;

import mtbs.mtbs.dto.MovieDto;
import mtbs.mtbs.dto.ScreensDto;
import mtbs.mtbs.Services.ScreensService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins="http://localhost:4200/")
@RequestMapping("/api/screens")
public class ScreensController {

    @Autowired
    private ScreensService screensService;

    @PostMapping("/add")
    public ResponseEntity<?> addScreen(@RequestBody ScreensDto dto, @RequestParam Integer adminId) {
        try {
            String res = screensService.addScreen(dto, adminId);
            return ResponseEntity.ok(res);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/")
    public ResponseEntity<List<ScreensDto>> getAllScreens() {
        return ResponseEntity.ok(screensService.getAllScreens());
    }
    
    @GetMapping("/{screenId}")
    public ResponseEntity<?> getScreenById(@PathVariable Integer screenId) {
        try {
            ScreensDto dto = screensService.getScreenById(screenId);
            return ResponseEntity.ok(dto);
        } catch (Exception e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }

    @GetMapping("/theatre/{theatreId}")
    public ResponseEntity<List<ScreensDto>> getScreensByTheatre(@PathVariable Integer theatreId) {
        return ResponseEntity.ok(screensService.getScreensByTheatre(theatreId));
    }

    @PutMapping("/{screenId}/update")
    public ResponseEntity<?> updateScreen(@PathVariable Integer screenId, @RequestBody ScreensDto updatedDto, @RequestParam Integer adminId) {
        try {
            String res = screensService.updateScreen(screenId, updatedDto, adminId);
            return ResponseEntity.ok(res);
        } catch (Exception e) {
            if (e.getMessage().equals("Screen not found")) {
                return ResponseEntity.status(404).body(e.getMessage());
            }
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/{screenId}/delete")
    public ResponseEntity<?> deleteScreen(@PathVariable Integer screenId, @RequestParam Integer adminId) {
        try {
            String res = screensService.deleteScreen(screenId, adminId);
            return ResponseEntity.ok(res);
        } catch (Exception e) {
            if (e.getMessage().equals("Screen not found")) {
                return ResponseEntity.status(404).body(e.getMessage());
            }
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
