package mtbs.mtbs.Enums;

public enum ActiveCodes {
	ACTIVE,INACTIVE
}
