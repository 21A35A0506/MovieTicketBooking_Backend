package mtbs.mtbs.dto;

import jakarta.persistence.Column;
import mtbs.mtbs.Enums.ActiveCodes;

public class ContactDto {
	
    private Integer contactId;

	private String name;

    private String email;

    private String message;
//    private ActiveCodes isActive;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

    public Integer getMovieId() {
		return contactId;
	}

	public void setMovieId(Integer movieId) {
		this.contactId = movieId;
	}

    
//    public ActiveCodes getIsActive() {
//		return isActive;
//	}
//	public void setIsActive(ActiveCodes isActive) {
//		this.isActive = isActive;
//	}
}
