package mtbs.mtbs.Model;

import jakarta.persistence.*;
import mtbs.mtbs.Enums.ActiveCodes;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Set;

@Entity
@Table(name = "showtimes")
public class Showtimes {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "showtime_id")
    private Integer showtimeId;

    @ManyToOne()
    @JoinColumn(name = "movie_id", nullable = false)
    private Movies movie;

    @ManyToOne()
    @JoinColumn(name = "screen_id", nullable = false)
    private Screens screen;

    @Column(name = "start_time", nullable = false)
    private LocalDateTime startTime;

    @Column(name = "end_time", nullable = false)
    private LocalDateTime endTime;

    @Column(name = "price", nullable = false, precision = 10, scale = 2)
    private BigDecimal price;

    @Column(name = "available_seats", nullable = false)
    private Integer availableSeats;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "is_active", nullable = false)
    private ActiveCodes isActive;

    @ManyToOne()
    @JoinColumn(name = "created_by", nullable = false)
    private Users createdBy;

    @Column(name = "created_at", nullable = false, updatable = false,
            columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp createdAt;

    @Column(name = "updated_at", nullable = false,
            columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    private Timestamp updatedAt;

    @OneToMany(mappedBy = "showtime", cascade = CascadeType.ALL)
    private Set<Bookings> bookings;
    
    
    @Column(name = "seats_list", columnDefinition = "TEXT", nullable = false)
    private String seatsList;

    public String getSeatsList() {
        return seatsList;
    }

    public void setSeatsList(String seatsList) {
        this.seatsList = seatsList;
    }

    // Constructors
    public Showtimes() {}

    public Showtimes(Movies movie, Screens screen, LocalDateTime startTime, LocalDateTime endTime,
                     BigDecimal price, Integer availableSeats, Users createdBy) {
        this.movie = movie;
        this.screen = screen;
        this.startTime = startTime;
        this.endTime = endTime;
        this.price = price;
        this.availableSeats = availableSeats;
        this.createdBy = createdBy;
    }

    // Getters and Setters
    public Integer getShowtimeId() { return showtimeId; }
    public void setShowtimeId(Integer showtimeId) { this.showtimeId = showtimeId; }

    public Movies getMovie() { return movie; }
    public void setMovie(Movies movie) { this.movie = movie; }

    public Screens getScreen() { return screen; }
    public void setScreen(Screens screen) { this.screen = screen; }

    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }

    public LocalDateTime getEndTime() { return endTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }

    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }

    public Integer getAvailableSeats() { return availableSeats; }
    public void setAvailableSeats(Integer availableSeats) { this.availableSeats = availableSeats; }

    public ActiveCodes getIsActive() { return isActive; }
    public void setIsActive(ActiveCodes isActive) { this.isActive = isActive; }
    
    public Users getCreatedBy() { return createdBy; }
    public void setCreatedBy(Users createdBy) { this.createdBy = createdBy; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public Timestamp getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Timestamp updatedAt) { this.updatedAt = updatedAt; }

    public Set<Bookings> getBookings() { return bookings; }
    public void setBookings(Set<Bookings> bookings) { this.bookings = bookings; }
}