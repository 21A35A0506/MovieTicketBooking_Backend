package mtbs.mtbs.dto;

import java.util.List;
import java.math.BigDecimal;
import java.sql.Timestamp;

public class BookingWithShowtimeDto {
    private Integer bookingId;
    private Integer userId;
    private String userName;
    private String userEmail;
    private String showtimeLabel;   // Morning, Matinee, Evening, Second Show
    private String movieTitle;
    private String theatreName;
    private String paymentStatus;
    private Timestamp bookingDate;
    private BigDecimal totalAmount;
    private List<String> seatNumbers;
    private Integer seatCount;

    // Getters and Setters
    public Integer getBookingId() { return bookingId; }
    public void setBookingId(Integer bookingId) { this.bookingId = bookingId; }

    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    public String getUserEmail() { return userEmail; }
    public void setUserEmail(String userEmail) { this.userEmail = userEmail; }

    public String getShowtimeLabel() { return showtimeLabel; }
    public void setShowtimeLabel(String showtimeLabel) { this.showtimeLabel = showtimeLabel; }

    public String getMovieTitle() { return movieTitle; }
    public void setMovieTitle(String movieTitle) { this.movieTitle = movieTitle; }

    public String getTheatreName() { return theatreName; }
    public void setTheatreName(String theatreName) { this.theatreName = theatreName; }

    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }

    public Timestamp getBookingDate() { return bookingDate; }
    public void setBookingDate(Timestamp bookingDate) { this.bookingDate = bookingDate; }

    public BigDecimal getTotalAmount() { return totalAmount; }
    public void setTotalAmount(BigDecimal totalAmount) { this.totalAmount = totalAmount; }

    public List<String> getSeatNumbers() { return seatNumbers; }
    public void setSeatNumbers(List<String> seatNumbers) { this.seatNumbers = seatNumbers; }

    public Integer getSeatCount() { return seatCount; }
    public void setSeatCount(Integer seatCount) { this.seatCount = seatCount; }
}