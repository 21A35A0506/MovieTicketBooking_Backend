package mtbs.mtbs.Repository;

import mtbs.mtbs.Model.Screens;
import mtbs.mtbs.Enums.ActiveCodes;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ScreensRepository extends JpaRepository<Screens, Integer> {
    List<Screens> findByTheatre_TheaterId(Integer theaterId);

    // New: status-based queries
    List<Screens> findByIsActive(ActiveCodes isActive);
    List<Screens> findByTheatre_TheaterIdAndIsActive(Integer theaterId, ActiveCodes isActive);
}
