package mtbs.mtbs.dto;

import java.util.List;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class TheatreShowtimeDto {

    private Integer theatreId;
    private String theatreName;
    private String theatreCity;

    private List<ShowtimeInfo> showtimes;

    public TheatreShowtimeDto() {}

    public TheatreShowtimeDto(Integer theatreId, String theatreName, String theatreCity, List<ShowtimeInfo> showtimes) {
        this.theatreId = theatreId;
        this.theatreName = theatreName;
        this.theatreCity = theatreCity;
        this.showtimes = showtimes;
    }

    // Getters and setters

    public Integer getTheatreId() {
        return theatreId;
    }

    public void setTheatreId(Integer theatreId) {
        this.theatreId = theatreId;
    }

    public String getTheatreName() {
        return theatreName;
    }

    public void setTheatreName(String theatreName) {
        this.theatreName = theatreName;
    }

    public String getTheatreCity() {
        return theatreCity;
    }

    public void setTheatreCity(String theatreCity) {
        this.theatreCity = theatreCity;
    }

    public List<ShowtimeInfo> getShowtimes() {
        return showtimes;
    }

    public void setShowtimes(List<ShowtimeInfo> showtimes) {
        this.showtimes = showtimes;
    }

    // Inner class to represent detailed showtime info
    public static class ShowtimeInfo {
        private Integer showtimeId;
        private LocalDateTime startTime;
        private LocalDateTime endTime;
        private BigDecimal price;
        private Integer availableSeats;

        private Integer movieId;
        private String movieTitle;

        private Integer screenId;
        private String screenName;

        public ShowtimeInfo() {}

        public ShowtimeInfo(Integer showtimeId, LocalDateTime startTime, LocalDateTime endTime, BigDecimal price,
                            Integer availableSeats, Integer movieId, String movieTitle,
                            Integer screenId, String screenName) {
            this.showtimeId = showtimeId;
            this.startTime = startTime;
            this.endTime = endTime;
            this.price = price;
            this.availableSeats = availableSeats;
            this.movieId = movieId;
            this.movieTitle = movieTitle;
            this.screenId = screenId;
            this.screenName = screenName;
        }

        // Getters and setters

        public Integer getShowtimeId() {
            return showtimeId;
        }

        public void setShowtimeId(Integer showtimeId) {
            this.showtimeId = showtimeId;
        }

        public LocalDateTime getStartTime() {
            return startTime;
        }

        public void setStartTime(LocalDateTime startTime) {
            this.startTime = startTime;
        }

        public LocalDateTime getEndTime() {
            return endTime;
        }

        public void setEndTime(LocalDateTime endTime) {
            this.endTime = endTime;
        }

        public BigDecimal getPrice() {
            return price;
        }

        public void setPrice(BigDecimal price) {
            this.price = price;
        }

        public Integer getAvailableSeats() {
            return availableSeats;
        }

        public void setAvailableSeats(Integer availableSeats) {
            this.availableSeats = availableSeats;
        }

        public Integer getMovieId() {
            return movieId;
        }

        public void setMovieId(Integer movieId) {
            this.movieId = movieId;
        }

        public String getMovieTitle() {
            return movieTitle;
        }

        public void setMovieTitle(String movieTitle) {
            this.movieTitle = movieTitle;
        }

        public Integer getScreenId() {
            return screenId;
        }

        public void setScreenId(Integer screenId) {
            this.screenId = screenId;
        }

        public String getScreenName() {
            return screenName;
        }

        public void setScreenName(String screenName) {
            this.screenName = screenName;
        }
    }
}
