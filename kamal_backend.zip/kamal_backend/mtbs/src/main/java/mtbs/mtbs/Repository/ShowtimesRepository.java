package mtbs.mtbs.Repository;

import mtbs.mtbs.Model.Showtimes;
import mtbs.mtbs.Enums.ActiveCodes;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface ShowtimesRepository extends JpaRepository<Showtimes, Integer> {
    List<Showtimes> findByMovie_MovieId(Integer movieId);
    List<Showtimes> findByScreen_ScreenId(Integer screenId);
    List<Showtimes> findByStartTimeBetween(LocalDateTime startTime, LocalDateTime endTime);
    List<Showtimes> findByMovie_MovieIdAndScreen_ScreenIdAndStartTimeBetween(
        Integer movieId, Integer screenId, LocalDateTime startTime, LocalDateTime endTime
    );

    // New: status-enabled queries
    List<Showtimes> findByIsActive(ActiveCodes isActive);
    List<Showtimes> findByMovie_MovieIdAndIsActive(Integer movieId, ActiveCodes isActive);
    List<Showtimes> findByScreen_ScreenIdAndIsActive(Integer screenId, ActiveCodes isActive);
    List<Showtimes> findByStartTimeBetweenAndIsActive(LocalDateTime startTime, LocalDateTime endTime, ActiveCodes isActive);
    List<Showtimes> findByMovie_MovieIdAndScreen_ScreenIdAndStartTimeBetweenAndIsActive(
        Integer movieId, Integer screenId, LocalDateTime startTime, LocalDateTime endTime, ActiveCodes isActive
    );
	List<Showtimes> findByMovie_MovieIdAndScreen_Theatre_TheaterIdAndIsActive(Integer movieId, Integer theatreId,
			ActiveCodes active);
}