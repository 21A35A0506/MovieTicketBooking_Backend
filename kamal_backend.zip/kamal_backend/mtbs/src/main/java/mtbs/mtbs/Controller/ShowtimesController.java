package mtbs.mtbs.Controller;

import mtbs.mtbs.dto.ScreenTheatreDto;
import mtbs.mtbs.dto.ShowtimeDto;
import mtbs.mtbs.dto.ShowtimeListDto;
import mtbs.mtbs.Services.ShowtimesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins="http://localhost:4200/")
@RequestMapping("/api/showtimes")
public class ShowtimesController {

    @Autowired
    private ShowtimesService showtimesService;

    @PostMapping("/add")
    public ResponseEntity<?> addShowtime(@RequestBody ShowtimeDto dto, @RequestParam Integer adminId) {
        try {
            String res = showtimesService.addShowtime(dto, adminId);
            return ResponseEntity.ok(res);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getUserById(@PathVariable Integer id) {
        try {
            ShowtimeDto userDto = showtimesService.getUserById(id);
            return ResponseEntity.ok(userDto);
        } catch (Exception e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }
    
    
    @GetMapping("/")
    public ResponseEntity<List<ShowtimeListDto>> getAllShowtimes() {
        return ResponseEntity.ok(showtimesService.getAllShowtimeListDtos());
    }
    

    @GetMapping("/screens-with-theatres")
    public ResponseEntity<List<ScreenTheatreDto>> getAllScreensWithTheatreInfo() {
        List<ScreenTheatreDto> screenTheatreList = showtimesService.getAllScreensWithTheatreInfo();
        return ResponseEntity.ok(screenTheatreList);
    }

    @GetMapping("/search")
    public ResponseEntity<List<ShowtimeDto>> searchShowtimes(
            @RequestParam(required = false) Integer movieId,
            @RequestParam(required = false) String movieName,
            @RequestParam(required = false) Integer screenId,
            @RequestParam(required = false) String theatreName,
            @RequestParam(required = false) String date
    ) {
        return ResponseEntity.ok(showtimesService.searchShowtimes(movieId, movieName, screenId, theatreName, date));
    }

    @PutMapping("/{showtimeId}/update")
    public ResponseEntity<?> updateShowtime(
            @PathVariable Integer showtimeId,
            @RequestBody ShowtimeDto updatedDto,
            @RequestParam Integer adminId
    ) {
        try {
            String res = showtimesService.updateShowtime(showtimeId, updatedDto, adminId);
            return ResponseEntity.ok(res);
        } catch (Exception e) {
            if (e.getMessage().equals("Showtime not found")) {
                return ResponseEntity.status(404).body(e.getMessage());
            }
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/{showtimeId}/delete")
    public ResponseEntity<?> deleteShowtime(@PathVariable Integer showtimeId, @RequestParam Integer adminId) {
        try {
            String res = showtimesService.deleteShowtime(showtimeId, adminId);
            return ResponseEntity.ok(res);
        } catch (Exception e) {
            if (e.getMessage().equals("Showtime not found")) {
                return ResponseEntity.status(404).body(e.getMessage());
            }
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}