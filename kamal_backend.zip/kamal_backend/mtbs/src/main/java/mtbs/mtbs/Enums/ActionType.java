package mtbs.mtbs.Enums;

public enum ActionType {
	INSERT, UPDATE, DELETE
}
