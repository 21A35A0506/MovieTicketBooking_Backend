package mtbs.mtbs.dto;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

public class BookingConfirmationDto {

    private Integer bookingId;
    private Timestamp bookingDate;
    private Integer showtimeId;
    private LocalDateTime showtimeStartTime;
    private LocalDateTime showtimeEndTime;
    private BigDecimal totalAmount;
    private String status;
    private String paymentStatus;

    private Integer movieId;
    private String movieTitle;

    private Integer theatreId;
    private String theatreName;

    private Integer screenId;
    private String screenName;

    private List<String> seatNumbers;
    private Integer seatCount;

    public BookingConfirmationDto() {}

    public BookingConfirmationDto(Integer bookingId, Timestamp bookingDate, Integer showtimeId,
                                  LocalDateTime showtimeStartTime, LocalDateTime showtimeEndTime,
                                  BigDecimal totalAmount, String status, String paymentStatus,
                                  Integer movieId, String movieTitle, Integer theatreId, String theatreName,
                                  Integer screenId, String screenName, List<String> seatNumbers, Integer seatCount) {
        this.bookingId = bookingId;
        this.bookingDate = bookingDate;
        this.showtimeId = showtimeId;
        this.showtimeStartTime = showtimeStartTime;
        this.showtimeEndTime = showtimeEndTime;
        this.totalAmount = totalAmount;
        this.status = status;
        this.paymentStatus = paymentStatus;
        this.movieId = movieId;
        this.movieTitle = movieTitle;
        this.theatreId = theatreId;
        this.theatreName = theatreName;
        this.screenId = screenId;
        this.screenName = screenName;
        this.seatNumbers = seatNumbers;
        this.seatCount = seatCount;
    }

    // Getters and setters

    public Integer getBookingId() {
        return bookingId;
    }

    public void setBookingId(Integer bookingId) {
        this.bookingId = bookingId;
    }

    public Timestamp getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(Timestamp bookingDate) {
        this.bookingDate = bookingDate;
    }

    public Integer getShowtimeId() {
        return showtimeId;
    }

    public void setShowtimeId(Integer showtimeId) {
        this.showtimeId = showtimeId;
    }

    public LocalDateTime getShowtimeStartTime() {
        return showtimeStartTime;
    }

    public void setShowtimeStartTime(LocalDateTime showtimeStartTime) {
        this.showtimeStartTime = showtimeStartTime;
    }

    public LocalDateTime getShowtimeEndTime() {
        return showtimeEndTime;
    }

    public void setShowtimeEndTime(LocalDateTime showtimeEndTime) {
        this.showtimeEndTime = showtimeEndTime;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public Integer getMovieId() {
        return movieId;
    }

    public void setMovieId(Integer movieId) {
        this.movieId = movieId;
    }

    public String getMovieTitle() {
        return movieTitle;
    }

    public void setMovieTitle(String movieTitle) {
        this.movieTitle = movieTitle;
    }

    public Integer getTheatreId() {
        return theatreId;
    }

    public void setTheatreId(Integer theatreId) {
        this.theatreId = theatreId;
    }

    public String getTheatreName() {
        return theatreName;
    }

    public void setTheatreName(String theatreName) {
        this.theatreName = theatreName;
    }

    public Integer getScreenId() {
        return screenId;
    }

    public void setScreenId(Integer screenId) {
        this.screenId = screenId;
    }

    public String getScreenName() {
        return screenName;
    }

    public void setScreenName(String screenName) {
        this.screenName = screenName;
    }

    public List<String> getSeatNumbers() {
        return seatNumbers;
    }

    public void setSeatNumbers(List<String> seatNumbers) {
        this.seatNumbers = seatNumbers;
    }

    public Integer getSeatCount() {
        return seatCount;
    }

    public void setSeatCount(Integer seatCount) {
        this.seatCount = seatCount;
    }
}
