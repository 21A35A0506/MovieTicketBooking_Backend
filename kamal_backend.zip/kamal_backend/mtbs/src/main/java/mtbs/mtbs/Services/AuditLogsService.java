package mtbs.mtbs.Services;

import mtbs.mtbs.Model.AuditLogs;
import mtbs.mtbs.Model.Users;
import mtbs.mtbs.Repository.AuditLogsRepository;
import mtbs.mtbs.Repository.UsersRepository;
import mtbs.mtbs.dto.AuditLogsDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AuditLogsService {

    @Autowired
    private AuditLogsRepository auditLogsRepository;

    @Autowired
    private UsersRepository usersRepository;

    private boolean isAdmin(Integer userId) {
        Optional<Users> userOpt = usersRepository.findById(userId);
        return userOpt.isPresent() && userOpt.get().getRole() == Users.Role.ADMIN;
    }

    public List<AuditLogsDto> getAllLogs(Integer adminId) throws SecurityException {
        if (!isAdmin(adminId)) throw new SecurityException("Unauthorized access");
        return auditLogsRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    public List<AuditLogsDto> getLogsByTable(String tableName, Integer adminId) throws SecurityException {
        if (!isAdmin(adminId)) throw new SecurityException("Unauthorized access");
        return auditLogsRepository.findByTableNameIgnoreCase(tableName)
                .stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    public List<AuditLogsDto> getLogsByRecord(Integer recordId, Integer adminId) throws SecurityException {
        if (!isAdmin(adminId)) throw new SecurityException("Unauthorized access");
        return auditLogsRepository.findByRecordId(recordId)
                .stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    public List<AuditLogsDto> getLogsByUser(Integer userId, Integer adminId) throws SecurityException {
        if (!isAdmin(adminId)) throw new SecurityException("Unauthorized access");
        return auditLogsRepository.findByChangedBy_UserId(userId)
                .stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    private AuditLogsDto convertToDto(AuditLogs log) {
        AuditLogsDto dto = new AuditLogsDto();
        dto.setAuditId(log.getLogId());
        dto.setTableName(log.getTableName());
        dto.setRecordId(log.getRecordId());
        dto.setAction(log.getAction());
        dto.setChangedById(
            log.getChangedBy() != null ? log.getChangedBy().getUserId() : null
        );
        dto.setChangedAt(log.getChangedAt());
        return dto;
    }
}
