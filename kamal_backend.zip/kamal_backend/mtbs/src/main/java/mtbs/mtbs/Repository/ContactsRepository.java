package mtbs.mtbs.Repository;

import mtbs.mtbs.Model.Contacts;
import mtbs.mtbs.Enums.ActiveCodes;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ContactsRepository extends JpaRepository<Contacts, Integer> {
    List<Contacts> findByIsActive(ActiveCodes status);

}
