package mtbs.mtbs.Services;

import mtbs.mtbs.Enums.ActionType;
import mtbs.mtbs.Enums.ActiveCodes;
import mtbs.mtbs.Model.Movies;
import mtbs.mtbs.Model.Screens;
import mtbs.mtbs.Model.Showtimes;
import mtbs.mtbs.Model.Theatres;
import mtbs.mtbs.Model.Users;
import mtbs.mtbs.Model.AuditLogs;
import mtbs.mtbs.Repository.*;
import mtbs.mtbs.dto.MovieDto;
import mtbs.mtbs.dto.MovieTheatresDto;
import mtbs.mtbs.dto.MovieWithShowtimesDto;
import mtbs.mtbs.dto.ShowtimeDto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MovieService {

	@Autowired
	private MoviesRepository moviesRepository;
	@Autowired
	private UsersRepository usersRepository;
	@Autowired
	private AuditLogsRepository auditLogsRepository;

	@Autowired
	private ShowtimesRepository showtimesRepository;

	@Transactional
	public String addMovie(MovieDto dto, Integer adminId) throws Exception {
		Optional<Users> adminOpt = usersRepository.findById(adminId);
		if (adminOpt.isEmpty() || adminOpt.get().getRole() != Users.Role.ADMIN) {
			throw new Exception("Only admins can add movies.");
		}
		Movies movie = new Movies();
		movie.setTitle(dto.getTitle());
		movie.setDescription(dto.getDescription());
		movie.setDuration(dto.getDuration());
		movie.setGenre(dto.getGenre());
		movie.setLanguage(dto.getLanguage());
		movie.setReleaseDate(dto.getReleaseDate());
		movie.setRating(dto.getRating());
		movie.setPosterUrl(dto.getPosterUrl());
		movie.setCreatedBy(adminOpt.get());
		movie.setIsActive(ActiveCodes.ACTIVE); // set as active on create
		movie.setCreatedAt(new Timestamp(System.currentTimeMillis()));
		movie.setUpdatedAt(new Timestamp(System.currentTimeMillis()));

		moviesRepository.save(movie);

		logAudit("movies", movie.getMovieId(), "INSERT", adminId);

		return "Movie added successfully!";
	}

	public List<MovieDto> getAllMovies() {
		// Only return active movies
		return moviesRepository.findByIsActive(ActiveCodes.ACTIVE).stream().map(this::convertToDto)
				.collect(Collectors.toList());
	}

	public List<MovieDto> searchMovies(String genre, String language) {
		List<Movies> results;
		if (genre != null && language != null) {
			results = moviesRepository.findByGenreIgnoreCaseAndLanguageIgnoreCaseAndIsActive(genre, language,
					ActiveCodes.ACTIVE);
		} else if (genre != null) {
			results = moviesRepository.findByGenreIgnoreCaseAndIsActive(genre, ActiveCodes.ACTIVE);
		} else if (language != null) {
			results = moviesRepository.findByLanguageIgnoreCaseAndIsActive(language, ActiveCodes.ACTIVE);
		} else {
			results = moviesRepository.findByIsActive(ActiveCodes.ACTIVE);
		}
		return results.stream().map(this::convertToDto).collect(Collectors.toList());
	}

	public List<MovieDto> getMoviesByName(String movieName) throws Exception {
		List<Movies> movies = moviesRepository.findByTitleIgnoreCaseAndIsActive(movieName, ActiveCodes.ACTIVE);
		if (movies == null || movies.isEmpty())
			throw new Exception("Movie not found");
		return movies.stream().map(this::convertToDto).collect(Collectors.toList());
	}

	public MovieDto getMovieById(Integer movieId) throws Exception {
		Optional<Movies> movieOpt = moviesRepository.findById(movieId);
		if (movieOpt.isEmpty() || movieOpt.get().getIsActive() != ActiveCodes.ACTIVE)
			throw new Exception("Movie not found");
		return convertToDto(movieOpt.get());
	}

	public MovieWithShowtimesDto getMovieWithShowtimesById(Integer movieId) throws Exception {
		Optional<Movies> movieOpt = moviesRepository.findById(movieId);
		if (movieOpt.isEmpty() || movieOpt.get().getIsActive() != ActiveCodes.ACTIVE)
			throw new Exception("Movie not found");

		// Fetch active showtimes for this movie
		List<Showtimes> showtimes = showtimesRepository.findByMovie_MovieIdAndIsActive(movieId, ActiveCodes.ACTIVE);

		// Use your static mapper
		return MovieWithShowtimesDto.from(movieOpt.get(), showtimes);
	}

	@Transactional
	public String updateMovie(Integer movieId, MovieDto dto, Integer adminId) throws Exception {
		Optional<Movies> movieOpt = moviesRepository.findById(movieId);
		Optional<Users> adminOpt = usersRepository.findById(adminId);

		if (movieOpt.isEmpty())
			throw new Exception("Movie not found");
		if (adminOpt.isEmpty() || adminOpt.get().getRole() != Users.Role.ADMIN)
			throw new Exception("Only admins can update movies.");

		Movies movie = movieOpt.get();
		movie.setTitle(dto.getTitle());
		movie.setDescription(dto.getDescription());
		movie.setDuration(dto.getDuration());
		movie.setGenre(dto.getGenre());
		movie.setLanguage(dto.getLanguage());
		movie.setReleaseDate(dto.getReleaseDate());
		movie.setRating(dto.getRating());
		movie.setPosterUrl(dto.getPosterUrl());
		movie.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
		moviesRepository.save(movie);

		logAudit("movies", movieId, "UPDATE", adminId);

		return "Movie updated successfully!";
	}

	// SOFT DELETE
	@Transactional
	public String deleteMovie(Integer movieId, Integer adminId) throws Exception {
		Optional<Movies> movieOpt = moviesRepository.findById(movieId);
		Optional<Users> adminOpt = usersRepository.findById(adminId);
		if (movieOpt.isEmpty())
			throw new Exception("Movie not found");
		if (adminOpt.isEmpty() || adminOpt.get().getRole() != Users.Role.ADMIN)
			throw new Exception("Only admins can delete movies.");

		Movies movie = movieOpt.get();
		movie.setIsActive(ActiveCodes.INACTIVE);
		moviesRepository.save(movie);

		logAudit("movies", movieId, "DELETE", adminId);

		return "Movie marked as inactive (soft deleted) successfully!";
	}

	private MovieDto convertToDto(Movies movie) {
		MovieDto dto = new MovieDto();
		dto.setMovieId(movie.getMovieId());
		dto.setTitle(movie.getTitle());
		dto.setDescription(movie.getDescription());
		dto.setDuration(movie.getDuration());
		dto.setGenre(movie.getGenre());
		dto.setLanguage(movie.getLanguage());
		dto.setReleaseDate(movie.getReleaseDate());
		dto.setRating(movie.getRating());
		dto.setPosterUrl(movie.getPosterUrl());
		return dto;
	}

	private void logAudit(String tableName, Integer recordId, String action, Integer changedById) {
		AuditLogs audit = new AuditLogs();
		audit.setTableName(tableName);
		audit.setRecordId(recordId);
		try {
			ActionType actionType = ActionType.valueOf(action.toUpperCase());
			audit.setAction(actionType);
		} catch (IllegalArgumentException e) {
			throw new IllegalArgumentException("Invalid action type: " + action);
		}
		Users user = new Users();
		user.setUserId(changedById);
		audit.setChangedBy(user);
		audit.setChangedAt(new Timestamp(System.currentTimeMillis()));
		auditLogsRepository.save(audit);
	}

	public List<MovieTheatresDto> getTheatresScreensShowtimesForMovie(Integer movieId) {
		List<Showtimes> showtimes = showtimesRepository.findByMovie_MovieIdAndIsActive(movieId, ActiveCodes.ACTIVE);

		// Maps theatreId -> MovieTheatresDto
		Map<Integer, MovieTheatresDto> theatreMap = new LinkedHashMap<>();

		// Maps screenId (within theatre) for deduplication and aggregation
		Map<String, MovieTheatresDto.ScreenWithShowtimes> screenMap = new HashMap<>();

		for (Showtimes showtime : showtimes) {
			Screens screen = showtime.getScreen();
			if (screen == null || screen.getIsActive() != ActiveCodes.ACTIVE)
				continue;
			Theatres theatre = screen.getTheatre();
			if (theatre == null || theatre.getIsActive() != ActiveCodes.ACTIVE)
				continue;

			// Build or get the theatre DTO
			MovieTheatresDto theatreDto = theatreMap.computeIfAbsent(theatre.getTheaterId(), k -> {
				MovieTheatresDto dto = new MovieTheatresDto();
				dto.setTheatreId(theatre.getTheaterId());
				dto.setTheatreName(theatre.getName());
				dto.setLocation(theatre.getLocation());
				dto.setCity(theatre.getCity());
				dto.setScreens(new ArrayList<>());
				return dto;
			});

			// Use a composite key (theatreId:screenId) for uniqueness
			String screenKey = theatre.getTheaterId() + ":" + screen.getScreenId();
			MovieTheatresDto.ScreenWithShowtimes screenDto = screenMap.get(screenKey);
			if (screenDto == null) {
				screenDto = new MovieTheatresDto.ScreenWithShowtimes();
				screenDto.setScreenId(screen.getScreenId());
				screenDto.setScreenName(screen.getScreenName());
				screenDto.setCapacity(screen.getCapacity());
				screenDto.setShowtimes(new ArrayList<>());
				theatreDto.getScreens().add(screenDto);
				screenMap.put(screenKey, screenDto);
			}

			// Add showtime to screen showtimes list
			screenDto.getShowtimes().add(convertShowtimeToDto(showtime));
		}

		return new ArrayList<>(theatreMap.values());
	}

	// Helper method to convert Showtimes entity to ShowtimeDto (reuse code as used
	// elsewhere)
	private ShowtimeDto convertShowtimeToDto(Showtimes showtime) {
		ShowtimeDto dto = new ShowtimeDto();
		dto.setShowtimeId(showtime.getShowtimeId());
		dto.setStartTime(showtime.getStartTime());
		dto.setEndTime(showtime.getEndTime());
		dto.setPrice(showtime.getPrice());
		dto.setAvailableSeats(showtime.getAvailableSeats());
		dto.setMovieId(showtime.getMovie() != null ? showtime.getMovie().getMovieId() : null);
		dto.setScreenId(showtime.getScreen() != null ? showtime.getScreen().getScreenId() : null);
		return dto;
	}
	
	
	
	public MovieTheatresDto getScreensShowtimesForMovieAndTheatre(Integer movieId, Integer theatreId) {
	    List<Showtimes> showtimes = showtimesRepository
	        .findByMovie_MovieIdAndScreen_Theatre_TheaterIdAndIsActive(
	            movieId, theatreId, ActiveCodes.ACTIVE
	        );

	    Theatres theatre = null;
	    Map<Integer, MovieTheatresDto.ScreenWithShowtimes> screenMap = new LinkedHashMap<>();

	    for (Showtimes showtime : showtimes) {
	        Screens screen = showtime.getScreen();
	        if (screen == null || screen.getIsActive() != ActiveCodes.ACTIVE)
	            continue;

	        if (theatre == null) {
	            theatre = screen.getTheatre();
	            if (theatre == null || theatre.getIsActive() != ActiveCodes.ACTIVE)
	                continue;
	        }

	        MovieTheatresDto.ScreenWithShowtimes screenDto = screenMap.computeIfAbsent(
	            screen.getScreenId(), k -> {
	                MovieTheatresDto.ScreenWithShowtimes dto = new MovieTheatresDto.ScreenWithShowtimes();
	                dto.setScreenId(screen.getScreenId());
	                dto.setScreenName(screen.getScreenName());
	                dto.setCapacity(screen.getCapacity());
	                dto.setShowtimes(new ArrayList<>());
	                return dto;
	            }
	        );
	        screenDto.getShowtimes().add(convertShowtimeToDto(showtime));
	    }

	    if (theatre == null) return null; // or throw, or return empty DTO

	    MovieTheatresDto result = new MovieTheatresDto();
	    result.setTheatreId(theatre.getTheaterId());
	    result.setTheatreName(theatre.getName());
	    result.setLocation(theatre.getLocation());
	    result.setCity(theatre.getCity());
	    result.setScreens(new ArrayList<>(screenMap.values()));

	    return result;
	}


}
