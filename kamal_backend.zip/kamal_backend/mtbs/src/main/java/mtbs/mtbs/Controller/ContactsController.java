package mtbs.mtbs.Controller;

import mtbs.mtbs.dto.ContactDto;
import mtbs.mtbs.dto.MovieDto;
import mtbs.mtbs.dto.TheatreDto;
import mtbs.mtbs.Services.ContactsService;
import mtbs.mtbs.Services.TheatresService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins="http://localhost:4200/")
@RequestMapping("/api/contacts")
public class ContactsController {

    @Autowired
    private ContactsService contactsService;

    @PostMapping("/add")
    public ResponseEntity<?> addContact(@RequestBody ContactDto dto , @RequestParam("userId") Integer userId) {
        try {
            String res = contactsService.addContact(dto, userId);
            return ResponseEntity.ok(res);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/")
    public ResponseEntity<List<ContactDto>> getAllContacts() {
        return ResponseEntity.ok(contactsService.getAllContacts());
    }

  
}
