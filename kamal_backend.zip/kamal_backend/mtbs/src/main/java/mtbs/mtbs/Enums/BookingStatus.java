package mtbs.mtbs.Enums;

public enum BookingStatus {
    CONFIRMED, CANCELLED, COMPLETED
}
