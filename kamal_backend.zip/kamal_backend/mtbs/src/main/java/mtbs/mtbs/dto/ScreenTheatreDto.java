package mtbs.mtbs.dto;

public class ScreenTheatreDto {
    private Integer screenId;
    private String screenName;
    private String theatreName;

    public ScreenTheatreDto(Integer screenId, String screenName, String theatreName) {
        this.screenId = screenId;
        this.screenName = screenName;
        this.theatreName = theatreName;
    }

    // Getters and setters
    public Integer getScreenId() { return screenId; }
    public void setScreenId(Integer screenId) { this.screenId = screenId; }

    public String getScreenName() { return screenName; }
    public void setScreenName(String screenName) { this.screenName = screenName; }

    public String getTheatreName() { return theatreName; }
    public void setTheatreName(String theatreName) { this.theatreName = theatreName; }
}
