package mtbs.mtbs.dto;

import mtbs.mtbs.Enums.ActiveCodes;

public class TheatreDto {
    private Integer theatreId;
    private String name;
    private String location;

	private String city;
    private Integer capacity;
//    private ActiveCodes isActive;

    public Integer getTheatreId() { return theatreId; }
    public void setTheatreId(Integer theatreId) { this.theatreId = theatreId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public Integer getCapacity() { return capacity; }
    public void setCapacity(Integer capacity) { this.capacity = capacity; }
    
//    public ActiveCodes getIsActive() {
//		return isActive;
//	}
//	public void setIsActive(ActiveCodes isActive) {
//		this.isActive = isActive;
//	}
}
