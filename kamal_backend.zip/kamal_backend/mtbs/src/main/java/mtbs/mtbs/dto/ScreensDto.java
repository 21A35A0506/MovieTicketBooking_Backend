package mtbs.mtbs.dto;

import mtbs.mtbs.Enums.ActiveCodes;

public class ScreensDto {
    private Integer screenId;
    private String screenName;
    private Integer capacity;
    private Integer theatreId;
    private ActiveCodes isActive;

//    private String seatsList;
//
//    public String getSeatsList() {
//        return seatsList;
//    }
//
//    public void setSeatsList(String seatsList) {
//        this.seatsList = seatsList;
//    }
    
    public Integer getScreenId() {
        return screenId;
    }
    public void setScreenId(Integer screenId) {
        this.screenId = screenId;
    }
    public String getScreenName() {
        return screenName;
    }
    public void setScreenName(String screenName) {
        this.screenName = screenName;
    }
    public Integer getCapacity() {
        return capacity;
    }
    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }
    public Integer getTheatreId() {
        return theatreId;
    }
    public void setTheatreId(Integer theatreId) {
        this.theatreId = theatreId;
    }
    public ActiveCodes getIsActive() {
		return isActive;
	}
	public void setIsActive(ActiveCodes isActive) {
		this.isActive = isActive;
	}
}
