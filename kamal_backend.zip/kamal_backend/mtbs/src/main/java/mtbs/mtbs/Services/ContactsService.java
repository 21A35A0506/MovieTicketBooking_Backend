package mtbs.mtbs.Services;

import mtbs.mtbs.Enums.ActionType;
import mtbs.mtbs.Enums.ActiveCodes;
import mtbs.mtbs.Model.*;
import mtbs.mtbs.Repository.*;
import mtbs.mtbs.dto.ContactDto;
import mtbs.mtbs.dto.MovieDto;
import mtbs.mtbs.dto.TheatreDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ContactsService {
    
    @Autowired
    private ContactsRepository contactsRepository;
    
    @Autowired
    private AuditLogsRepository auditLogsRepository;

    @Autowired
	private UsersRepository usersRepository;

    @Transactional
    public String addContact(ContactDto dto, Integer userId) throws Exception {
    	
        Optional<Users> adminOpt = usersRepository.findByUserId(userId);
        if (adminOpt.isEmpty() ) {
            throw new Exception("No User.");
        }
 
        Contacts contacts = new Contacts();
        contacts.setName(dto.getName());
        contacts.setEmail(dto.getEmail());
        contacts.setMessage(dto.getMessage());

     
        contacts.setIsActive(ActiveCodes.ACTIVE); // status
        contacts.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        contacts.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
        contactsRepository.save(contacts);

        logAudit("contacts", contacts.getContactsId(), "INSERT", userId);

        return "Contact added successfully!";
    }


    public List<ContactDto> getAllContacts() {
        // Only return active movies
        return contactsRepository.findByIsActive(ActiveCodes.ACTIVE).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }
    
    
    private ContactDto convertToDto(Contacts contact) {
        ContactDto dto = new ContactDto();
        dto.setMovieId(contact.getContactsId());
        dto.setName(contact.getName());
        dto.setEmail(contact.getEmail());
        dto.setMessage(contact.getMessage());
        return dto;
    }
    
    private void logAudit(String tableName, Integer recordId, String action, Integer changedById) {
        AuditLogs audit = new AuditLogs();
        audit.setTableName(tableName);
        audit.setRecordId(recordId);
        try {
            ActionType actionType = ActionType.valueOf(action.toUpperCase());
            audit.setAction(actionType);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid action type: " + action);
        }
        Users user = new Users();
        user.setUserId(changedById);
        audit.setChangedBy(user);
        audit.setChangedAt(new Timestamp(System.currentTimeMillis()));
        auditLogsRepository.save(audit);
    }

}
